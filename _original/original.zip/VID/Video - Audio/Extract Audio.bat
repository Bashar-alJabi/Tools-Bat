@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Extract Audio - FFmpeg

:: ============================================================
:: Extract Audio from Video using FFmpeg
::
:: Input files  : .\Input
:: Output files : .\Output
:: Format       : MP3
:: Quality      : High
:: ============================================================


:: ------------------------------------------------------------
:: Set folders relative to this BAT file
:: ------------------------------------------------------------

set "SCRIPT_DIR=%~dp0"
set "INPUT_DIR=%SCRIPT_DIR%Input"
set "OUTPUT_DIR=%SCRIPT_DIR%Output"


:: ------------------------------------------------------------
:: Check FFmpeg
:: ------------------------------------------------------------

where ffmpeg >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: FFmpeg was not found.
    echo.
    pause
    exit /b 1
)


:: ------------------------------------------------------------
:: Check Input folder
:: ------------------------------------------------------------

if not exist "%INPUT_DIR%" (
    echo.
    echo ERROR: Input folder was not found.
    echo.
    echo Expected:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"


:: ------------------------------------------------------------
:: Count input files
:: ------------------------------------------------------------

set /a FOUND=0

for %%F in (
    "%INPUT_DIR%\*.mp4"
    "%INPUT_DIR%\*.mov"
    "%INPUT_DIR%\*.mkv"
    "%INPUT_DIR%\*.avi"
    "%INPUT_DIR%\*.m4v"
    "%INPUT_DIR%\*.webm"
) do (
    if exist "%%~F" set /a FOUND+=1
)


:: ------------------------------------------------------------
:: No files found
:: ------------------------------------------------------------

if %FOUND% EQU 0 (
    echo.
    echo No supported video files were found in:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 0
)


:: ------------------------------------------------------------
:: Processing
:: ------------------------------------------------------------

echo.
echo ============================================================
echo                    EXTRACT AUDIO
echo ============================================================
echo.

echo Input:
echo %INPUT_DIR%
echo.

echo Output:
echo %OUTPUT_DIR%
echo.

echo Format:
echo MP3
echo.

echo Quality:
echo High - VBR q:a 2
echo.

echo Found %FOUND% video(s).
echo.

echo ============================================================
echo                     PROCESSING
echo ============================================================
echo.

set /a CURRENT=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0

for %%F in (
    "%INPUT_DIR%\*.mp4"
    "%INPUT_DIR%\*.mov"
    "%INPUT_DIR%\*.mkv"
    "%INPUT_DIR%\*.avi"
    "%INPUT_DIR%\*.m4v"
    "%INPUT_DIR%\*.webm"
) do (

    if exist "%%~F" (

        set /a CURRENT+=1

        set "INPUT_FILE=%%~F"
        set "OUTPUT_FILE=%OUTPUT_DIR%\%%~nF.mp3"

        echo.
        echo ------------------------------------------------------------
        echo [!CURRENT!/%FOUND%] %%~nxF
        echo ------------------------------------------------------------
        echo.

        if exist "!OUTPUT_FILE!" (

            echo SKIPPED - Output already exists:
            echo !OUTPUT_FILE!

            set /a SKIPPED+=1

        ) else (

            ffmpeg ^
                -hide_banner ^
                -i "!INPUT_FILE!" ^
                -map 0:a:0 ^
                -vn ^
                -c:a libmp3lame ^
                -q:a 2 ^
                -y ^
                "!OUTPUT_FILE!"

            if errorlevel 1 (

                echo.
                echo FAILED: %%~nxF
                set /a FAILED+=1

                if exist "!OUTPUT_FILE!" del /q "!OUTPUT_FILE!" >nul 2>&1

            ) else (

                echo.
                echo DONE: %%~nF.mp3
                set /a SUCCESS+=1

            )
        )
    )
)


:: ------------------------------------------------------------
:: Summary
:: ------------------------------------------------------------

echo.
echo ============================================================
echo                  EXTRACTION FINISHED
echo ============================================================
echo.

echo Total videos : %FOUND%
echo Successful   : %SUCCESS%
echo Failed       : %FAILED%
echo Skipped      : %SKIPPED%
echo.

echo Output:
echo %OUTPUT_DIR%
echo.

pause
endlocal