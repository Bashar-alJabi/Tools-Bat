@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Normalize Audio - FFmpeg

:: ============================================================
:: Normalize Video Audio using FFmpeg
::
:: Input files  : .\Input
:: Output files : .\Output
::
:: Video        : No re-encoding
:: Audio        : AAC 192k
:: Filter       : loudnorm
:: ============================================================


:: ------------------------------------------------------------
:: Set folders relative to this BAT file
:: ------------------------------------------------------------

set "SCRIPT_DIR=%~dp0"
set "INPUT_DIR=%SCRIPT_DIR%Input"
set "OUTPUT_DIR=%SCRIPT_DIR%Output"


:: ------------------------------------------------------------
:: Check FFmpeg
:: ------------------------------------------------------------

where ffmpeg >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: FFmpeg was not found.
    echo.
    pause
    exit /b 1
)


:: ------------------------------------------------------------
:: Check Input folder
:: ------------------------------------------------------------

if not exist "%INPUT_DIR%" (
    echo.
    echo ERROR: Input folder was not found.
    echo.
    echo Expected:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"


:: ------------------------------------------------------------
:: Count supported files
:: ------------------------------------------------------------

set /a FOUND=0

for %%F in (
    "%INPUT_DIR%\*.mp4"
    "%INPUT_DIR%\*.mov"
    "%INPUT_DIR%\*.mkv"
    "%INPUT_DIR%\*.avi"
    "%INPUT_DIR%\*.m4v"
    "%INPUT_DIR%\*.webm"
) do (
    if exist "%%~F" set /a FOUND+=1
)


:: ------------------------------------------------------------
:: No files found
:: ------------------------------------------------------------

if %FOUND% EQU 0 (
    echo.
    echo No supported video files were found in:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 0
)


:: ------------------------------------------------------------
:: Display settings
:: ------------------------------------------------------------

echo.
echo ============================================================
echo                   NORMALIZE AUDIO
echo ============================================================
echo.
echo Input:
echo %INPUT_DIR%
echo.
echo Output:
echo %OUTPUT_DIR%
echo.
echo Audio:
echo AAC 192k
echo.
echo Normalization:
echo loudnorm
echo.
echo Video:
echo Copy - No re-encoding
echo.
echo Found %FOUND% video(s).
echo.
echo ============================================================
echo                     PROCESSING
echo ============================================================
echo.


:: ------------------------------------------------------------
:: Counters
:: ------------------------------------------------------------

set /a CURRENT=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0


:: ------------------------------------------------------------
:: Process videos
:: ------------------------------------------------------------

for %%F in (
    "%INPUT_DIR%\*.mp4"
    "%INPUT_DIR%\*.mov"
    "%INPUT_DIR%\*.mkv"
    "%INPUT_DIR%\*.avi"
    "%INPUT_DIR%\*.m4v"
    "%INPUT_DIR%\*.webm"
) do (

    if exist "%%~F" (

        set /a CURRENT+=1

        set "INPUT_FILE=%%~F"
        set "OUTPUT_FILE=%OUTPUT_DIR%\%%~nF.mp4"


        echo.
        echo ------------------------------------------------------------
        echo [!CURRENT!/%FOUND%] %%~nxF
        echo ------------------------------------------------------------
        echo.

        if exist "!OUTPUT_FILE!" (

            echo SKIPPED - Output already exists:
            echo !OUTPUT_FILE!

            set /a SKIPPED+=1

        ) else (

            ffmpeg ^
                -hide_banner ^
                -i "!INPUT_FILE!" ^
                -map 0:v:0 ^
                -map 0:a:0 ^
                -af loudnorm ^
                -c:v copy ^
                -c:a aac ^
                -b:a 192k ^
                -movflags +faststart ^
                -y ^
                "!OUTPUT_FILE!"

            if errorlevel 1 (

                echo.
                echo FAILED: %%~nxF

                set /a FAILED+=1

                if exist "!OUTPUT_FILE!" (
                    del /q "!OUTPUT_FILE!" >nul 2>&1
                )

            ) else (

                echo.
                echo DONE: %%~nF.mp4

                set /a SUCCESS+=1
            )
        )
    )
)


:: ------------------------------------------------------------
:: Finished
:: ------------------------------------------------------------

echo.
echo ============================================================
echo                  PROCESSING FINISHED
echo ============================================================
echo.

echo Total videos : %FOUND%
echo Successful   : %SUCCESS%
echo Failed       : %FAILED%
echo Skipped      : %SKIPPED%
echo.

echo Output:
echo %OUTPUT_DIR%
echo.

pause
endlocal