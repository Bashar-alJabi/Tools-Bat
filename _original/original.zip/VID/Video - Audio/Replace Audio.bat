@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Replace Audio - FFmpeg

:: ============================================================
:: Replace Audio in Video using FFmpeg
::
:: Input files  : .\Input
:: Output files : .\Output
::
:: Put:
::     1 Video file
::     1 Audio file
::
:: The original video audio is removed and replaced
:: with the new audio file.
:: ============================================================


:: ------------------------------------------------------------
:: Set folders
:: ------------------------------------------------------------

set "SCRIPT_DIR=%~dp0"
set "INPUT_DIR=%SCRIPT_DIR%Input"
set "OUTPUT_DIR=%SCRIPT_DIR%Output"


:: ------------------------------------------------------------
:: Check FFmpeg
:: ------------------------------------------------------------

where ffmpeg >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: FFmpeg was not found.
    echo.
    pause
    exit /b 1
)


:: ------------------------------------------------------------
:: Check Input folder
:: ------------------------------------------------------------

if not exist "%INPUT_DIR%" (
    echo.
    echo ERROR: Input folder was not found.
    echo.
    echo Expected:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"


:: ------------------------------------------------------------
:: Find video
:: ------------------------------------------------------------

set "VIDEO="

for %%F in (
    "%INPUT_DIR%\*.mp4"
    "%INPUT_DIR%\*.mov"
    "%INPUT_DIR%\*.mkv"
    "%INPUT_DIR%\*.avi"
    "%INPUT_DIR%\*.m4v"
    "%INPUT_DIR%\*.webm"
) do (
    if exist "%%~F" if not defined VIDEO set "VIDEO=%%~F"
)


:: ------------------------------------------------------------
:: Find audio
:: ------------------------------------------------------------

set "AUDIO="

for %%F in (
    "%INPUT_DIR%\*.mp3"
    "%INPUT_DIR%\*.wav"
    "%INPUT_DIR%\*.m4a"
    "%INPUT_DIR%\*.aac"
    "%INPUT_DIR%\*.flac"
    "%INPUT_DIR%\*.ogg"
) do (
    if exist "%%~F" if not defined AUDIO set "AUDIO=%%~F"
)


:: ------------------------------------------------------------
:: Check files
:: ------------------------------------------------------------

if not defined VIDEO (
    echo.
    echo ERROR: No video file was found in:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 1
)

if not defined AUDIO (
    echo.
    echo ERROR: No audio file was found in:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 1
)


:: ------------------------------------------------------------
:: Set output file
:: ------------------------------------------------------------

set "OUTPUT_FILE=%OUTPUT_DIR%\replaced.mp4"


:: ------------------------------------------------------------
:: Check existing output
:: ------------------------------------------------------------

if exist "%OUTPUT_FILE%" (
    echo.
    echo ============================================================
    echo                    REPLACE AUDIO
    echo ============================================================
    echo.
    echo Output already exists:
    echo %OUTPUT_FILE%
    echo.
    echo SKIPPED
    echo.
    pause
    exit /b 0
)


:: ------------------------------------------------------------
:: Replace audio
:: ------------------------------------------------------------

echo.
echo ============================================================
echo                    REPLACE AUDIO
echo ============================================================
echo.

echo Video:
echo %VIDEO%
echo.

echo New Audio:
echo %AUDIO%
echo.

echo Output:
echo %OUTPUT_FILE%
echo.

echo Original audio:
echo Removed
echo.

echo Video:
echo Copy - No re-encoding
echo.

echo Audio:
echo AAC 192k
echo.

echo ------------------------------------------------------------
echo.


ffmpeg ^
    -hide_banner ^
    -i "%VIDEO%" ^
    -i "%AUDIO%" ^
    -map 0:v:0 ^
    -map 1:a:0 ^
    -c:v copy ^
    -c:a aac ^
    -b:a 192k ^
    -movflags +faststart ^
    -shortest ^
    -y ^
    "%OUTPUT_FILE%"


:: ------------------------------------------------------------
:: Check result
:: ------------------------------------------------------------

if errorlevel 1 (
    echo.
    echo ERROR: Failed to replace audio.

    if exist "%OUTPUT_FILE%" (
        del /q "%OUTPUT_FILE%" >nul 2>&1
    )

    set /a FAILED=1
    set /a SUCCESS=0
) else (
    echo.
    echo DONE:
    echo %OUTPUT_FILE%

    set /a SUCCESS=1
    set /a FAILED=0
)


:: ------------------------------------------------------------
:: Finished
:: ------------------------------------------------------------

echo.
echo ============================================================
echo                  PROCESSING FINISHED
echo ============================================================
echo.

echo Successful : %SUCCESS%
echo Failed     : %FAILED%
echo Skipped    : 0
echo.

echo Output:
echo %OUTPUT_DIR%
echo.

pause
endlocal