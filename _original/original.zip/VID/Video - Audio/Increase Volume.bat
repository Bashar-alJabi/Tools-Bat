@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Increase Volume - FFmpeg

:: ============================================================
:: Increase Video Audio Volume using FFmpeg
::
:: Input files  : .\Input
:: Output files : .\Output
:: Video        : No re-encoding
:: Audio        : AAC 192k
:: ============================================================


:: ------------------------------------------------------------
:: Set folders relative to this BAT file
:: ------------------------------------------------------------

set "SCRIPT_DIR=%~dp0"
set "INPUT_DIR=%SCRIPT_DIR%Input"
set "OUTPUT_DIR=%SCRIPT_DIR%Output"


:: ------------------------------------------------------------
:: Check FFmpeg
:: ------------------------------------------------------------

where ffmpeg >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: FFmpeg was not found.
    echo.
    pause
    exit /b 1
)


:: ------------------------------------------------------------
:: Check Input folder
:: ------------------------------------------------------------

if not exist "%INPUT_DIR%" (
    echo.
    echo ERROR: Input folder was not found.
    echo.
    echo Expected:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"


:: ------------------------------------------------------------
:: Count input files
:: ------------------------------------------------------------

set /a FOUND=0

for %%F in (
    "%INPUT_DIR%\*.mp4"
    "%INPUT_DIR%\*.mov"
    "%INPUT_DIR%\*.mkv"
    "%INPUT_DIR%\*.avi"
    "%INPUT_DIR%\*.m4v"
    "%INPUT_DIR%\*.webm"
) do (
    if exist "%%~F" set /a FOUND+=1
)


:: ------------------------------------------------------------
:: No files found
:: ------------------------------------------------------------

if %FOUND% EQU 0 (
    echo.
    echo No supported video files were found in:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 0
)


:: ------------------------------------------------------------
:: Volume menu
:: ------------------------------------------------------------

:MENU

cls

echo.
echo ============================================================
echo                    INCREASE VOLUME
echo ============================================================
echo.
echo Found %FOUND% video(s).
echo.
echo Select volume increase:
echo.
echo [1] +3 dB
echo     Slight increase
echo.
echo [2] +6 dB
echo     Clear increase
echo.
echo [3] +9 dB
echo     Strong increase
echo.
echo [4] +12 dB
echo     Very strong increase
echo.
echo [Q] Quit
echo.

choice /c 1234Q /n /m "Select an option: "

if errorlevel 5 goto QUIT
if errorlevel 4 set "VOLUME=12dB" & set "VOLUME_LABEL=+12 dB" & set "VOLUME_DESC=Very strong increase" & goto CONFIRM
if errorlevel 3 set "VOLUME=9dB" & set "VOLUME_LABEL=+9 dB" & set "VOLUME_DESC=Strong increase" & goto CONFIRM
if errorlevel 2 set "VOLUME=6dB" & set "VOLUME_LABEL=+6 dB" & set "VOLUME_DESC=Clear increase" & goto CONFIRM
if errorlevel 1 set "VOLUME=3dB" & set "VOLUME_LABEL=+3 dB" & set "VOLUME_DESC=Slight increase" & goto CONFIRM

goto MENU


:: ------------------------------------------------------------
:: Confirmation
:: ------------------------------------------------------------

:CONFIRM

cls

echo.
echo ============================================================
echo                    CONFIRM SETTINGS
echo ============================================================
echo.

echo Volume increase:
echo    !VOLUME_LABEL!
echo.

echo Description:
echo    !VOLUME_DESC!
echo.

echo Video:
echo    Copy - No re-encoding
echo.

echo Audio:
echo    AAC 192k
echo.

echo Input:
echo    %INPUT_DIR%
echo.

echo Output:
echo    %OUTPUT_DIR%
echo.

echo WARNING:
echo    Increasing volume may cause clipping or distortion
echo    if the original audio is already close to its maximum.
echo.

choice /c YN /n /m "Continue? [Y/N]: "

if errorlevel 2 goto MENU
if errorlevel 1 goto PROCESS

goto MENU


:: ------------------------------------------------------------
:: Processing
:: ------------------------------------------------------------

:PROCESS

cls

echo.
echo ============================================================
echo                   INCREASE VOLUME
echo ============================================================
echo.

echo Volume:
echo    !VOLUME_LABEL!
echo.

echo Found %FOUND% video(s).
echo.

echo ============================================================
echo                     PROCESSING
echo ============================================================
echo.

set /a CURRENT=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0

for %%F in (
    "%INPUT_DIR%\*.mp4"
    "%INPUT_DIR%\*.mov"
    "%INPUT_DIR%\*.mkv"
    "%INPUT_DIR%\*.avi"
    "%INPUT_DIR%\*.m4v"
    "%INPUT_DIR%\*.webm"
) do (

    if exist "%%~F" (

        set /a CURRENT+=1

        set "INPUT_FILE=%%~F"
        set "OUTPUT_FILE=%OUTPUT_DIR%\%%~nF.mp4"

        echo.
        echo ------------------------------------------------------------
        echo [!CURRENT!/%FOUND%] %%~nxF
        echo ------------------------------------------------------------
        echo.

        if exist "!OUTPUT_FILE!" (

            echo SKIPPED - Output already exists:
            echo !OUTPUT_FILE!

            set /a SKIPPED+=1

        ) else (

            ffmpeg ^
                -hide_banner ^
                -i "!INPUT_FILE!" ^
                -map 0:v:0 ^
                -map 0:a:0 ^
                -filter:a "volume=!VOLUME!" ^
                -c:v copy ^
                -c:a aac ^
                -b:a 192k ^
                -movflags +faststart ^
                -y ^
                "!OUTPUT_FILE!"

            if errorlevel 1 (

                echo.
                echo FAILED: %%~nxF
                set /a FAILED+=1

                if exist "!OUTPUT_FILE!" del /q "!OUTPUT_FILE!" >nul 2>&1

            ) else (

                echo.
                echo DONE: %%~nF.mp4
                set /a SUCCESS+=1

            )
        )
    )
)


:: ------------------------------------------------------------
:: Summary
:: ------------------------------------------------------------

echo.
echo ============================================================
echo                  PROCESSING FINISHED
echo ============================================================
echo.

echo Volume increase : !VOLUME_LABEL!
echo.
echo Total videos     : %FOUND%
echo Successful       : %SUCCESS%
echo Failed           : %FAILED%
echo Skipped          : %SKIPPED%
echo.

echo Output:
echo %OUTPUT_DIR%
echo.

pause
goto END


:: ------------------------------------------------------------
:: Quit
:: ------------------------------------------------------------

:QUIT

cls

echo.
echo Volume increase cancelled.
echo.


:: ------------------------------------------------------------
:: End
:: ------------------------------------------------------------

:END

endlocal