@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Video Resolution Converter

:: ============================================================
:: Video Resolution Converter
:: ============================================================

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ------------------------------------------------------------
:: Check FFmpeg
:: ------------------------------------------------------------

where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] FFmpeg was not found.
    echo Make sure FFmpeg is installed and available in PATH.
    echo.
    pause
    exit /b 1
)

:: ------------------------------------------------------------
:: Check Input folder
:: ------------------------------------------------------------

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder not found:
    echo %INPUT%
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ------------------------------------------------------------
:: Resolution Menu
:: ------------------------------------------------------------

:MENU
cls
echo.
echo ============================================================
echo              VIDEO RESOLUTION CONVERTER
echo ============================================================
echo.
echo  1. 4K       - 3840 x 2160
echo  2. 1080p    - 1920 x 1080
echo  3. 720p     - 1280 x 720
echo  4. 480p     - 854 x 480
echo.
set "CHOICE="
set /p "CHOICE=Select resolution [1-4]: "

if "%CHOICE%"=="1" (
    set "WIDTH=3840"
    set "HEIGHT=2160"
    set "LABEL=4K"
    goto START
)

if "%CHOICE%"=="2" (
    set "WIDTH=1920"
    set "HEIGHT=1080"
    set "LABEL=1080p"
    goto START
)

if "%CHOICE%"=="3" (
    set "WIDTH=1280"
    set "HEIGHT=720"
    set "LABEL=720p"
    goto START
)

if "%CHOICE%"=="4" (
    set "WIDTH=854"
    set "HEIGHT=480"
    set "LABEL=480p"
    goto START
)

echo.
echo [ERROR] Invalid selection.
timeout /t 2 >nul
goto MENU

:: ------------------------------------------------------------
:: Start Processing
:: ------------------------------------------------------------

:START
cls
echo.
echo ============================================================
echo              VIDEO RESOLUTION CONVERTER
echo ============================================================
echo.
echo Target Resolution: %LABEL% (up to %WIDTH%x%HEIGHT%)
echo Aspect Ratio:      Preserved
echo FPS:               Preserved
echo Audio:             AAC
echo Scaling:           High Quality
echo Output Format:     MP4
echo.
echo Input:
echo %INPUT%
echo.
echo Output:
echo %OUTPUT%
echo.
echo ============================================================
echo.

set /a TOTAL=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0

:: ------------------------------------------------------------
:: Process videos
:: ------------------------------------------------------------

for %%F in (
    "%INPUT%\*.mp4"
    "%INPUT%\*.mkv"
    "%INPUT%\*.mov"
    "%INPUT%\*.avi"
    "%INPUT%\*.webm"
    "%INPUT%\*.m4v"
) do (
    if exist "%%~F" (
        set /a TOTAL+=1

        set "OUTPUT_FILE=%OUTPUT%\%%~nF_%LABEL%.mp4"

        echo.
        echo ------------------------------------------------------------
        echo Processing: %%~nxF
        echo Target: %LABEL%
        echo ------------------------------------------------------------

        if exist "!OUTPUT_FILE!" (
            echo [SKIPPED] Output already exists.
            set /a SKIPPED+=1
        ) else (
            ffmpeg -hide_banner -loglevel error -stats ^
                -i "%%~F" ^
                -map 0:v:0 ^
                -map 0:a? ^
                -vf "scale=%WIDTH%:%HEIGHT%:force_original_aspect_ratio=decrease:force_divisible_by=2" ^
                -sws_flags lanczos ^
                -c:v libx264 ^
                -preset medium ^
                -crf 16 ^
                -c:a aac ^
                -b:a 128k ^
                -map_metadata 0 ^
                -movflags +faststart ^
                "!OUTPUT_FILE!"

            if errorlevel 1 (
                echo [FAILED] Conversion failed.
                if exist "!OUTPUT_FILE!" del /q "!OUTPUT_FILE!" >nul 2>&1
                set /a FAILED+=1
            ) else (
                echo [SUCCESS] Converted successfully.
                set /a SUCCESS+=1
            )
        )
    )
)

:: ------------------------------------------------------------
:: Summary
:: ------------------------------------------------------------

echo.
echo.
echo ============================================================
echo                     SUMMARY
echo ============================================================
echo.
echo Resolution : %LABEL% (up to %WIDTH%x%HEIGHT%)
echo Total      : %TOTAL%
echo Success    : %SUCCESS%
echo Failed     : %FAILED%
echo Skipped    : %SKIPPED%
echo.
echo Output:
echo %OUTPUT%
echo.
echo ============================================================
echo.

pause
exit /b 0