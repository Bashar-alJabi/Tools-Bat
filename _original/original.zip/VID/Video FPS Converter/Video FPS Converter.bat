@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Video FPS Converter

:: ============================================================
:: Video FPS Converter
:: ============================================================

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ------------------------------------------------------------
:: Check FFmpeg
:: ------------------------------------------------------------

where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] FFmpeg was not found.
    echo Make sure FFmpeg is installed and available in PATH.
    echo.
    pause
    exit /b 1
)

:: ------------------------------------------------------------
:: Check Input folder
:: ------------------------------------------------------------

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder not found:
    echo %INPUT%
    echo.
    pause
    exit /b 1
)

:: ------------------------------------------------------------
:: Create Output folder
:: ------------------------------------------------------------

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ------------------------------------------------------------
:: FPS Selection
:: ------------------------------------------------------------

:MENU
cls
echo.
echo ============================================================
echo                   VIDEO FPS CONVERTER
echo ============================================================
echo.
echo  1. 24 FPS
echo  2. 25 FPS
echo  3. 30 FPS
echo  4. 50 FPS
echo  5. 60 FPS
echo.

set "CHOICE="
set /p "CHOICE=Select FPS [1-5]: "

if "%CHOICE%"=="1" (
    set "FPS=24"
    goto START
)

if "%CHOICE%"=="2" (
    set "FPS=25"
    goto START
)

if "%CHOICE%"=="3" (
    set "FPS=30"
    goto START
)

if "%CHOICE%"=="4" (
    set "FPS=50"
    goto START
)

if "%CHOICE%"=="5" (
    set "FPS=60"
    goto START
)

echo.
echo [ERROR] Invalid selection.
timeout /t 2 >nul
goto MENU

:: ------------------------------------------------------------
:: Start Processing
:: ------------------------------------------------------------

:START
cls
echo.
echo ============================================================
echo                   VIDEO FPS CONVERTER
echo ============================================================
echo.
echo Target FPS:     %FPS%
echo Audio:          AAC
echo Resolution:     Preserved
echo Output Format:  MP4
echo.
echo Input:
echo %INPUT%
echo.
echo Output:
echo %OUTPUT%
echo.
echo ============================================================
echo.

set /a TOTAL=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0

:: ------------------------------------------------------------
:: Process Videos
:: ------------------------------------------------------------

for %%F in (
    "%INPUT%\*.mp4"
    "%INPUT%\*.mkv"
    "%INPUT%\*.mov"
    "%INPUT%\*.avi"
    "%INPUT%\*.webm"
    "%INPUT%\*.m4v"
) do (
    if exist "%%~F" (
        set /a TOTAL+=1
        set "OUTPUT_FILE=%OUTPUT%\%%~nF_%FPS%fps.mp4"

        echo.
        echo ------------------------------------------------------------
        echo Processing: %%~nxF
        echo Target FPS: %FPS%
        echo ------------------------------------------------------------

        if exist "!OUTPUT_FILE!" (
            echo [SKIPPED] Output already exists.
            set /a SKIPPED+=1
        ) else (

            ffmpeg -hide_banner -loglevel error -stats ^
                -i "%%~F" ^
                -map 0:v:0 ^
                -map 0:a? ^
                -vf "fps=%FPS%" ^
                -c:v libx264 ^
                -preset medium ^
                -crf 18 ^
                -c:a aac ^
                -b:a 192k ^
                -map_metadata 0 ^
                -movflags +faststart ^
                "!OUTPUT_FILE!"

            if errorlevel 1 (
                echo [FAILED] Conversion failed.
                if exist "!OUTPUT_FILE!" del /q "!OUTPUT_FILE!" >nul 2>&1
                set /a FAILED+=1
            ) else (
                echo [SUCCESS] Converted successfully.
                set /a SUCCESS+=1
            )
        )
    )
)

:: ------------------------------------------------------------
:: Summary
:: ------------------------------------------------------------

echo.
echo.
echo ============================================================
echo                     SUMMARY
echo ============================================================
echo.
echo Target FPS : %FPS%
echo Total      : %TOTAL%
echo Success    : %SUCCESS%
echo Failed     : %FAILED%
echo Skipped    : %SKIPPED%
echo.
echo Output:
echo %OUTPUT%
echo.
echo ============================================================
echo.

pause
exit /b 0