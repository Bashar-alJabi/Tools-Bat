@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Video Compression - FFmpeg

echo.
echo ==================================================
echo              VIDEO COMPRESSION
echo ==================================================
echo.

:: ==================================================
:: Paths
:: ==================================================

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ==================================================
:: Check FFmpeg
:: ==================================================

where ffmpeg >nul 2>&1

if errorlevel 1 (
    echo ERROR: FFmpeg was not found.
    echo.
    echo Please install FFmpeg and add it to PATH.
    echo.
    pause
    exit /b 1
)

:: ==================================================
:: Check Input
:: ==================================================

if not exist "%INPUT%" (
    echo ERROR: Input folder was not found.
    echo.
    echo Expected:
    echo %INPUT%
    echo.
    pause
    exit /b 1
)

:: ==================================================
:: Create Output
:: ==================================================

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ==================================================
:: Check NVIDIA NVENC availability
:: ==================================================

set "USE_H264_NVENC=0"
set "USE_HEVC_NVENC=0"

ffmpeg -hide_banner -encoders 2>nul | findstr /I "h264_nvenc" >nul

if not errorlevel 1 (
    set "USE_H264_NVENC=1"
)

ffmpeg -hide_banner -encoders 2>nul | findstr /I "hevc_nvenc" >nul

if not errorlevel 1 (
    set "USE_HEVC_NVENC=1"
)

:: ==================================================
:: Compression Menu
:: ==================================================

:MENU

echo.
echo ==================================================
echo                COMPRESSION OPTIONS
echo ==================================================
echo.
echo [1] H.264 - Balanced
echo     Good quality + good compression
echo.
echo [2] H.264 - Smaller
echo     Stronger compression + smaller file
echo.
echo [3] H.264 - High Quality
echo     Higher quality + larger file
echo.
echo [4] H.265 / HEVC - Smaller
echo     Better compression + lower compatibility
echo.
echo [Q] Quit
echo.
echo ==================================================
echo.

set "CHOICE="
set /p "CHOICE=Select an option [1-4]: "

if /I "%CHOICE%"=="Q" exit /b 0

if "%CHOICE%"=="1" goto OPTION_BALANCED
if "%CHOICE%"=="2" goto OPTION_SMALLER
if "%CHOICE%"=="3" goto OPTION_HIGH
if "%CHOICE%"=="4" goto OPTION_HEVC

echo.
echo Invalid option.
echo Please select 1, 2, 3, 4 or Q.
echo.
goto MENU


:: ==================================================
:: Option 1 - H.264 Balanced
:: ==================================================

:OPTION_BALANCED

set "MODE=H.264"
set "MODE_NAME=H.264 - Balanced"
set "CRF=23"
set "CQ=23"
set "AUDIO_BITRATE=128k"

goto CONFIRM


:: ==================================================
:: Option 2 - H.264 Smaller
:: ==================================================

:OPTION_SMALLER

set "MODE=H.264"
set "MODE_NAME=H.264 - Smaller"
set "CRF=26"
set "CQ=26"
set "AUDIO_BITRATE=128k"

goto CONFIRM


:: ==================================================
:: Option 3 - H.264 High Quality
:: ==================================================

:OPTION_HIGH

set "MODE=H.264"
set "MODE_NAME=H.264 - High Quality"
set "CRF=20"
set "CQ=20"
set "AUDIO_BITRATE=160k"

goto CONFIRM


:: ==================================================
:: Option 4 - H.265 / HEVC
:: ==================================================

:OPTION_HEVC

set "MODE=H.265"
set "MODE_NAME=H.265 / HEVC - Smaller"
set "CRF=26"
set "CQ=26"
set "AUDIO_BITRATE=128k"

goto CONFIRM


:: ==================================================
:: Confirmation
:: ==================================================

:CONFIRM

echo.
echo ==================================================
echo                  SELECTED MODE
echo ==================================================
echo.
echo Mode:
echo    %MODE_NAME%
echo.

if "%MODE%"=="H.264" (
    if "%USE_H264_NVENC%"=="1" (
        echo Encoder:
        echo    NVIDIA NVENC
        echo.
        echo Codec:
        echo    H.264 NVENC
        echo.
        echo Quality:
        echo    CQ %CQ%
        echo.
        echo Preset:
        echo    P5
    ) else (
        echo Encoder:
        echo    CPU
        echo.
        echo Codec:
        echo    H.264 x264
        echo.
        echo Quality:
        echo    CRF %CRF%
        echo.
        echo Preset:
        echo    Medium
    )
) else (
    if "%USE_HEVC_NVENC%"=="1" (
        echo Encoder:
        echo    NVIDIA NVENC
        echo.
        echo Codec:
        echo    H.265 / HEVC NVENC
        echo.
        echo Quality:
        echo    CQ %CQ%
        echo.
        echo Preset:
        echo    P5
    ) else (
        echo Encoder:
        echo    CPU
        echo.
        echo Codec:
        echo    H.265 / HEVC x265
        echo.
        echo Quality:
        echo    CRF %CRF%
        echo.
        echo Preset:
        echo    Medium
    )
)

echo.
echo Audio:
echo    AAC %AUDIO_BITRATE%
echo.
echo Output:
echo    MP4
echo.

set "CONFIRM="
set /p "CONFIRM=Start compression? [Y/N]: "

if /I "%CONFIRM%"=="Y" goto START_COMPRESSION
if /I "%CONFIRM%"=="N" goto MENU

echo.
echo Invalid option.
goto CONFIRM


:: ==================================================
:: Start Compression
:: ==================================================

:START_COMPRESSION

echo.
echo ==================================================
echo                  PROCESSING
echo ==================================================
echo.

:: ==================================================
:: Counters
:: ==================================================

set /a FOUND=0
set /a CURRENT=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0

:: ==================================================
:: Count Videos
:: ==================================================

for %%F in (
    "%INPUT%\*.mp4"
    "%INPUT%\*.mov"
    "%INPUT%\*.mkv"
    "%INPUT%\*.avi"
    "%INPUT%\*.m4v"
    "%INPUT%\*.webm"
) do (
    if exist "%%~F" (
        set /a FOUND+=1
    )
)

if %FOUND% EQU 0 (
    echo No supported video files were found in:
    echo %INPUT%
    echo.
    pause
    exit /b 0
)

echo Found %FOUND% video(s).
echo.

:: ==================================================
:: Process Videos
:: ==================================================

for %%F in (
    "%INPUT%\*.mp4"
    "%INPUT%\*.mov"
    "%INPUT%\*.mkv"
    "%INPUT%\*.avi"
    "%INPUT%\*.m4v"
    "%INPUT%\*.webm"
) do (

    if exist "%%~F" (

        set /a CURRENT+=1
        set "NAME=%%~nF"
        set "OUTPUT_FILE=%OUTPUT%\!NAME!.mp4"

        REM --------------------------------------------------
        REM Original file size
        REM --------------------------------------------------

        set "INPUT_SIZE=%%~zF"

        echo --------------------------------------------------
        echo [!CURRENT!/%FOUND%] %%~nxF
        echo --------------------------------------------------
        echo.

        REM --------------------------------------------------
        REM Skip existing output
        REM --------------------------------------------------

        if exist "!OUTPUT_FILE!" (

            echo SKIPPED - Output already exists
            echo.

            set /a SKIPPED+=1

        ) else (

            REM --------------------------------------------------
            REM NVIDIA NVENC / CPU
            REM --------------------------------------------------

            if "%MODE%"=="H.264" (

                if "%USE_H264_NVENC%"=="1" (

                    ffmpeg -hide_banner -i "%%~F" -map 0:v:0 -map 0:a? -c:v h264_nvenc -cq %CQ% -preset p5 -c:a aac -b:a %AUDIO_BITRATE% -movflags +faststart "!OUTPUT_FILE!"

                ) else (

                    REM --------------------------------------------------
                    REM CPU x264
                    REM --------------------------------------------------

                    ffmpeg -hide_banner -i "%%~F" -map 0:v:0 -map 0:a? -c:v libx264 -crf %CRF% -preset medium -c:a aac -b:a %AUDIO_BITRATE% -movflags +faststart "!OUTPUT_FILE!"

                )

            ) else (

                if "%USE_HEVC_NVENC%"=="1" (

                    ffmpeg -hide_banner -i "%%~F" -map 0:v:0 -map 0:a? -c:v hevc_nvenc -cq %CQ% -preset p5 -c:a aac -b:a %AUDIO_BITRATE% -movflags +faststart "!OUTPUT_FILE!"

                ) else (

                    REM --------------------------------------------------
                    REM CPU x265
                    REM --------------------------------------------------

                    ffmpeg -hide_banner -i "%%~F" -map 0:v:0 -map 0:a? -c:v libx265 -crf %CRF% -preset medium -c:a aac -b:a %AUDIO_BITRATE% -movflags +faststart "!OUTPUT_FILE!"

                )
            )

            REM --------------------------------------------------
            REM Check result
            REM --------------------------------------------------

            if errorlevel 1 (

                echo.
                echo FAILED:
                echo    %%~nxF
                echo.

                if exist "!OUTPUT_FILE!" (
                    del /q "!OUTPUT_FILE!" >nul 2>&1
                )

                set /a FAILED+=1

            ) else (

                REM --------------------------------------------------
                REM Compressed file size
                REM --------------------------------------------------

                for %%S in ("!OUTPUT_FILE!") do (
                    set "OUTPUT_SIZE=%%~zS"
                )

                REM --------------------------------------------------
                REM Calculate saved size
                REM --------------------------------------------------

                set /a SAVED_SIZE=!INPUT_SIZE!-!OUTPUT_SIZE!

                REM --------------------------------------------------
                REM Convert sizes to MB
                REM --------------------------------------------------

                set /a INPUT_MB=!INPUT_SIZE!/1048576
                set /a OUTPUT_MB=!OUTPUT_SIZE!/1048576
                set /a SAVED_MB=!SAVED_SIZE!/1048576

                REM --------------------------------------------------
                REM Calculate reduction percentage
                REM --------------------------------------------------

                if !INPUT_SIZE! GTR 0 (
                    set /a REDUCTION=!SAVED_SIZE!*100/!INPUT_SIZE!
                ) else (
                    set /a REDUCTION=0
                )

                echo.
                echo DONE:
                echo    Output\!NAME!.mp4
                echo.
                echo    Original size : !INPUT_MB! MB
                echo    Compressed    : !OUTPUT_MB! MB

                if !SAVED_SIZE! GEQ 0 (
                    echo    Saved         : !SAVED_MB! MB
                    echo    Reduction     : !REDUCTION!%%
                ) else (
                    set /a INCREASE_SIZE=!OUTPUT_SIZE!-!INPUT_SIZE!
                    set /a INCREASE_MB=!INCREASE_SIZE!/1048576

                    echo    Size increase : !INCREASE_MB! MB
                    echo    Reduction     : !REDUCTION!%%
                )

                echo.

                set /a SUCCESS+=1
            )
        )

        echo.
    )
)


:: ==================================================
:: Finished
:: ==================================================

echo.
echo ==================================================
echo              COMPRESSION FINISHED
echo ==================================================
echo.

echo Total videos:  %FOUND%
echo Successful:    %SUCCESS%
echo Failed:        %FAILED%
echo Skipped:       %SKIPPED%
echo.

echo Mode:
echo %MODE_NAME%
echo.

if "%MODE%"=="H.264" (
    if "%USE_H264_NVENC%"=="1" (
        echo Encoder:
        echo NVIDIA NVENC
    ) else (
        echo Encoder:
        echo CPU x264
    )
) else (
    if "%USE_HEVC_NVENC%"=="1" (
        echo Encoder:
        echo NVIDIA NVENC
    ) else (
        echo Encoder:
        echo CPU x265
    )
)

echo.
echo Output:
echo %OUTPUT%
echo.

pause
endlocal