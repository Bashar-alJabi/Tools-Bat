@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Video Speed

:: ============================================================
:: Video Speed
:: ============================================================

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ------------------------------------------------------------
:: Check FFmpeg
:: ------------------------------------------------------------

where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] FFmpeg was not found.
    echo Make sure FFmpeg is installed and available in PATH.
    echo.
    pause
    exit /b 1
)

:: ------------------------------------------------------------
:: Check Input folder
:: ------------------------------------------------------------

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder not found:
    echo %INPUT%
    echo.
    pause
    exit /b 1
)

:: ------------------------------------------------------------
:: Create Output folder
:: ------------------------------------------------------------

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ------------------------------------------------------------
:: Speed Selection
:: ------------------------------------------------------------

:MENU
cls
echo.
echo ============================================================
echo                       VIDEO SPEED
echo ============================================================
echo.
echo  1. 0.5x   - Half Speed
echo  2. 0.75x  - Slower
echo  3. 1.25x  - Slightly Faster
echo  4. 1.5x   - Faster
echo  5. 2x     - Double Speed
echo.

set "CHOICE="
set /p "CHOICE=Select speed [1-5]: "

if "%CHOICE%"=="1" (
    set "SPEED=0.5"
    set "LABEL=0.5x"
    set "ATEMPO=0.5"
    goto START
)

if "%CHOICE%"=="2" (
    set "SPEED=0.75"
    set "LABEL=0.75x"
    set "ATEMPO=0.75"
    goto START
)

if "%CHOICE%"=="3" (
    set "SPEED=1.25"
    set "LABEL=1.25x"
    set "ATEMPO=1.25"
    goto START
)

if "%CHOICE%"=="4" (
    set "SPEED=1.5"
    set "LABEL=1.5x"
    set "ATEMPO=1.5"
    goto START
)

if "%CHOICE%"=="5" (
    set "SPEED=2"
    set "LABEL=2x"
    set "ATEMPO=2"
    goto START
)

echo.
echo [ERROR] Invalid selection.
timeout /t 2 >nul
goto MENU

:: ------------------------------------------------------------
:: Start Processing
:: ------------------------------------------------------------

:START
cls
echo.
echo ============================================================
echo                       VIDEO SPEED
echo ============================================================
echo.
echo Target Speed:    %LABEL%
echo Audio:           AAC
echo Pitch:           Preserved
echo Resolution:      Preserved
echo Output Format:   MP4
echo.
echo Input:
echo %INPUT%
echo.
echo Output:
echo %OUTPUT%
echo.
echo ============================================================
echo.

set /a TOTAL=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0

:: ------------------------------------------------------------
:: Process Videos
:: ------------------------------------------------------------

for %%F in (
    "%INPUT%\*.mp4"
    "%INPUT%\*.mkv"
    "%INPUT%\*.mov"
    "%INPUT%\*.avi"
    "%INPUT%\*.webm"
    "%INPUT%\*.m4v"
) do (
    if exist "%%~F" (
        set /a TOTAL+=1
        set "OUTPUT_FILE=%OUTPUT%\%%~nF_%LABEL%.mp4"

        echo.
        echo ------------------------------------------------------------
        echo Processing: %%~nxF
        echo Target Speed: %LABEL%
        echo ------------------------------------------------------------

        if exist "!OUTPUT_FILE!" (
            echo [SKIPPED] Output already exists.
            set /a SKIPPED+=1
        ) else (
            ffmpeg -hide_banner -loglevel error -stats ^
                -i "%%~F" ^
                -map 0:v:0 ^
                -map 0:a? ^
                -vf "setpts=PTS/%SPEED%" ^
                -af "atempo=%ATEMPO%" ^
                -c:v libx264 ^
                -preset medium ^
                -crf 18 ^
                -c:a aac ^
                -b:a 192k ^
                -map_metadata 0 ^
                -movflags +faststart ^
                "!OUTPUT_FILE!"

            if errorlevel 1 (
                echo [FAILED] Conversion failed.
                if exist "!OUTPUT_FILE!" del /q "!OUTPUT_FILE!" >nul 2>&1
                set /a FAILED+=1
            ) else (
                echo [SUCCESS] Converted successfully.
                set /a SUCCESS+=1
            )
        )
    )
)

:: ------------------------------------------------------------
:: Summary
:: ------------------------------------------------------------

echo.
echo.
echo ============================================================
echo                     SUMMARY
echo ============================================================
echo.
echo Target Speed : %LABEL%
echo Total        : %TOTAL%
echo Success      : %SUCCESS%
echo Failed       : %FAILED%
echo Skipped      : %SKIPPED%
echo.
echo Output:
echo %OUTPUT%
echo.
echo ============================================================
echo.

pause
exit /b 0