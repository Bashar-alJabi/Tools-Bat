@echo off
setlocal EnableExtensions

title Image Enhance

set "INPUT=%~dp0Input"
set "OUTPUT=%~dp0Output"

where magick >nul 2>&1
if errorlevel 1 (
    echo.
    echo ============================================================
    echo ERROR: ImageMagick was not found.
    echo ============================================================
    echo.
    echo Please install ImageMagick and make sure "magick"
    echo is available in PATH.
    echo.
    pause
    exit /b 1
)

if not exist "%INPUT%" mkdir "%INPUT%"
if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:MENU
cls
echo ============================================================
echo                     IMAGE ENHANCE
echo ============================================================
echo.
echo Input : %INPUT%
echo Output: %OUTPUT%
echo.
echo Select enhancement level:
echo.
echo [1] Light
echo [2] Medium
echo [3] Strong
echo [Q] Quit
echo.

set "CHOICE="
set /p "CHOICE=Enter choice: "

if "%CHOICE%"=="1" (
    set "LEVEL=Light"
    set "SHARPEN=0x0.8+0.8+0.03"
    goto CONFIRM
)

if "%CHOICE%"=="2" (
    set "LEVEL=Medium"
    set "SHARPEN=0x1.2+1+0.05"
    goto CONFIRM
)

if "%CHOICE%"=="3" (
    set "LEVEL=Strong"
    set "SHARPEN=0x1.6+1+0.08"
    goto CONFIRM
)

if /i "%CHOICE%"=="Q" exit /b 0

echo.
echo Invalid choice.
pause
goto MENU


:CONFIRM
cls
echo ============================================================
echo                    ENHANCEMENT SETTINGS
echo ============================================================
echo.
echo Level : %LEVEL%
echo Scale : 200%%
echo.
echo Processing:
echo   - Upscale image to 200%%
echo   - Lanczos resize filter
echo   - Sharpen details
echo.
echo Input : %INPUT%
echo Output: %OUTPUT%
echo.

set "START="
set /p "START=Start enhancement? [Y/N]: "

if /i not "%START%"=="Y" goto MENU

goto PROCESS


:PROCESS
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0
set /a TOTAL=0

echo.
echo ============================================================
echo                    STARTING ENHANCEMENT
echo ============================================================
echo.

for %%F in ("%INPUT%\*.jpg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.png") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.webp") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.bmp") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.gif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.avif") do call :PROCESS_IMAGE "%%~fF"

echo.
echo ============================================================
echo                         SUMMARY
echo ============================================================
echo.
echo Total   : %TOTAL%
echo Success : %SUCCESS%
echo Failed  : %FAILED%
echo Skipped : %SKIPPED%
echo.
echo Output folder:
echo %OUTPUT%
echo.

pause
exit /b 0


:PROCESS_IMAGE
set /a TOTAL+=1

set "INPUT_FILE=%~1"
set "FILENAME=%~nx1"
set "NAME=%~n1"
set "EXT=%~x1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%%EXT%"

echo Processing: %FILENAME%

if exist "%OUTPUT_FILE%" (
    echo   SKIPPED - Output already exists.
    echo.
    set /a SKIPPED+=1
    exit /b
)

set "TEMP_FILE=%TEMP%\image_enhance_%RANDOM%_%RANDOM%.png"

magick "%INPUT_FILE%" ^
    -auto-orient ^
    -filter Lanczos ^
    -resize "200%%" ^
    -unsharp %SHARPEN% ^
    "%TEMP_FILE%"

if errorlevel 1 goto FAILED_IMAGE

magick "%TEMP_FILE%" ^
    "%OUTPUT_FILE%"

if errorlevel 1 goto FAILED_IMAGE

if exist "%TEMP_FILE%" del /q "%TEMP_FILE%" >nul 2>&1

echo   SUCCESS
echo.

set /a SUCCESS+=1

exit /b


:FAILED_IMAGE
if exist "%TEMP_FILE%" del /q "%TEMP_FILE%" >nul 2>&1
if exist "%OUTPUT_FILE%" del /q "%OUTPUT_FILE%" >nul 2>&1

echo   FAILED
echo.

set /a FAILED+=1

exit /b