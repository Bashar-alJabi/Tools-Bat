@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Image Metadata Cleaner - ImageMagick

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ============================================================
:: CHECK IMAGEMAGICK
:: ============================================================

where magick >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] ImageMagick was not found.
    echo.
    echo Please install ImageMagick and make sure "magick"
    echo is available in PATH.
    echo.
    pause
    exit /b 1
)

:: ============================================================
:: CHECK INPUT
:: ============================================================

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder was not found:
    echo "%INPUT%"
    echo.
    mkdir "%INPUT%" >nul 2>&1
    echo Input folder has been created.
    echo Add your images and run the tool again.
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ============================================================
:: CONFIRM
:: ============================================================

:CONFIRM

cls
echo ============================================================
echo                 IMAGE METADATA CLEANER
echo                     ImageMagick
echo ============================================================
echo.
echo Input : "%INPUT%"
echo Output: "%OUTPUT%"
echo.
echo This tool removes image metadata such as:
echo.
echo - EXIF
echo - GPS / Location
echo - Camera information
echo - Date / Time metadata
echo - Software / Editing information
echo - Author / Copyright metadata
echo - Comments and other removable metadata
echo.
echo Image dimensions and visual content are preserved.
echo.
choice /C YN /N /M "Start metadata cleaning? [Y/N]: "

if errorlevel 2 exit /b 0

:: ============================================================
:: START CLEANING
:: ============================================================

:START_CLEANING

set /A FOUND=0
set /A CURRENT=0
set /A SUCCESS=0
set /A FAILED=0
set /A SKIPPED=0

echo.
echo ============================================================
echo                 STARTING METADATA CLEANING
echo ============================================================
echo.

:: ------------------------------------------------------------
:: JPG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.jpg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: PNG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.png") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: WEBP
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.webp") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: TIFF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.tif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: BMP
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.bmp") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: GIF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.gif") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: AVIF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.avif") do call :PROCESS_IMAGE "%%~fF"

:: ============================================================
:: SUMMARY
:: ============================================================

echo.
echo ============================================================
echo              METADATA CLEANING COMPLETE
echo ============================================================
echo.
echo Total files : %FOUND%
echo Successful  : %SUCCESS%
echo Failed      : %FAILED%
echo Skipped     : %SKIPPED%
echo.
echo Output      : "%OUTPUT%"
echo.
echo ============================================================
echo.

pause
exit /b 0


:: ============================================================
:: PROCESS IMAGE
:: ============================================================

:PROCESS_IMAGE

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "EXT=%~x1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%%EXT%"

echo [%CURRENT%] Processing: %NAME%%EXT%

:: Skip if output already exists
if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

:: ============================================================
:: REMOVE METADATA
:: ============================================================

magick "%INPUT_FILE%" -strip "%OUTPUT_FILE%"

:: ============================================================
:: CHECK RESULT
:: ============================================================

if errorlevel 1 (
    echo     [FAILED] Metadata cleaning failed.

    if exist "%OUTPUT_FILE%" del /Q "%OUTPUT_FILE%" >nul 2>&1

    set /A FAILED+=1
    echo.
    exit /b 0
)

if not exist "%OUTPUT_FILE%" (
    echo     [FAILED] Output file was not created.
    set /A FAILED+=1
    echo.
    exit /b 0
)

echo     [SUCCESS] %NAME%%EXT%
set /A SUCCESS+=1
echo.

exit /b 0