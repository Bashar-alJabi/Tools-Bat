@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Image Conversion - ImageMagick

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ============================================================
:: CHECK IMAGEMAGICK
:: ============================================================

where magick >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] ImageMagick was not found.
    echo.
    echo Please install ImageMagick and make sure "magick"
    echo is available in PATH.
    echo.
    pause
    exit /b 1
)

:: ============================================================
:: CHECK INPUT
:: ============================================================

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder was not found:
    echo "%INPUT%"
    echo.
    mkdir "%INPUT%" >nul 2>&1
    echo Input folder has been created.
    echo Add your images and run the tool again.
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ============================================================
:: MENU
:: ============================================================

:MENU

cls
echo ============================================================
echo                    IMAGE CONVERTER
echo                    ImageMagick
echo ============================================================
echo.
echo Input : "%INPUT%"
echo Output: "%OUTPUT%"
echo.
echo Select output format:
echo.
echo [1] JPG
echo [2] PNG
echo [3] WebP
echo [4] TIFF
echo [5] BMP
echo [6] GIF
echo [7] AVIF
echo [Q] Quit
echo.

choice /C 1234567Q /N /M "Select an option: "

if errorlevel 8 exit /b 0
if errorlevel 7 set "FORMAT=avif" & goto SETTINGS
if errorlevel 6 set "FORMAT=gif"  & goto SETTINGS
if errorlevel 5 set "FORMAT=bmp"  & goto SETTINGS
if errorlevel 4 set "FORMAT=tiff" & goto SETTINGS
if errorlevel 3 set "FORMAT=webp" & goto SETTINGS
if errorlevel 2 set "FORMAT=png"  & goto SETTINGS
if errorlevel 1 set "FORMAT=jpg"  & goto SETTINGS

:: ============================================================
:: FORMAT SETTINGS
:: ============================================================

:SETTINGS

set "QUALITY=85"

if /I "%FORMAT%"=="jpg" (
    echo.
    set /P "QUALITY=JPG quality (1-100) [85]: "
    if not defined QUALITY set "QUALITY=85"
)

if /I "%FORMAT%"=="webp" (
    echo.
    set /P "QUALITY=WebP quality (1-100) [85]: "
    if not defined QUALITY set "QUALITY=85"
)

if /I "%FORMAT%"=="avif" (
    echo.
    set /P "QUALITY=AVIF quality (1-100) [85]: "
    if not defined QUALITY set "QUALITY=85"
)

:: ============================================================
:: CONFIRM
:: ============================================================

:CONFIRM

cls
echo ============================================================
echo                    IMAGE CONVERTER
echo ============================================================
echo.
echo Input format : JPG / JPEG / PNG / WEBP / TIFF / BMP / GIF / AVIF
echo Output format: %FORMAT%
echo.

if /I "%FORMAT%"=="jpg" echo Quality: %QUALITY%
if /I "%FORMAT%"=="webp" echo Quality: %QUALITY%
if /I "%FORMAT%"=="avif" echo Quality: %QUALITY%

echo.
echo Output folder:
echo "%OUTPUT%"
echo.
choice /C YN /N /M "Start conversion? [Y/N]: "

if errorlevel 2 goto MENU

:: ============================================================
:: START CONVERSION
:: ============================================================

:START_CONVERSION

set /A FOUND=0
set /A CURRENT=0
set /A SUCCESS=0
set /A FAILED=0
set /A SKIPPED=0

echo.
echo ============================================================
echo                    STARTING CONVERSION
echo ============================================================
echo.

:: ------------------------------------------------------------
:: JPG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.jpg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: PNG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.png") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: WEBP
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.webp") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: TIFF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.tif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: BMP
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.bmp") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: GIF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.gif") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: AVIF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.avif") do call :PROCESS_IMAGE "%%~fF"

:: ============================================================
:: SUMMARY
:: ============================================================

echo.
echo ============================================================
echo                    CONVERSION COMPLETE
echo ============================================================
echo.
echo Total files : %FOUND%
echo Successful  : %SUCCESS%
echo Failed      : %FAILED%
echo Skipped     : %SKIPPED%
echo.
echo Format      : %FORMAT%
echo Output      : "%OUTPUT%"
echo.
echo ============================================================
echo.

pause
exit /b 0


:: ============================================================
:: PROCESS IMAGE
:: ============================================================

:PROCESS_IMAGE

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%.%FORMAT%"

echo [%CURRENT%] Processing: %NAME%

:: Skip if output already exists
if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

:: ============================================================
:: CONVERT
:: ============================================================

if /I "%FORMAT%"=="jpg" (
    magick "%INPUT_FILE%" -background white -alpha remove -alpha off -quality %QUALITY% "%OUTPUT_FILE%"
    goto CHECK_RESULT
)

if /I "%FORMAT%"=="webp" (
    magick "%INPUT_FILE%" -quality %QUALITY% "%OUTPUT_FILE%"
    goto CHECK_RESULT
)

if /I "%FORMAT%"=="avif" (
    magick "%INPUT_FILE%" -quality %QUALITY% "%OUTPUT_FILE%"
    goto CHECK_RESULT
)

magick "%INPUT_FILE%" "%OUTPUT_FILE%"

:: ============================================================
:: CHECK RESULT
:: ============================================================

:CHECK_RESULT

if errorlevel 1 (
    echo     [FAILED] Conversion failed.
    
    if exist "%OUTPUT_FILE%" del /Q "%OUTPUT_FILE%" >nul 2>&1
    
    set /A FAILED+=1
    echo.
    exit /b 0
)

if not exist "%OUTPUT_FILE%" (
    echo     [FAILED] Output file was not created.
    set /A FAILED+=1
    echo.
    exit /b 0
)

echo     [SUCCESS] %NAME%.%FORMAT%
set /A SUCCESS+=1
echo.

exit /b 0