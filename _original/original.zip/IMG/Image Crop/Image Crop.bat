@echo off
setlocal EnableExtensions

title Image Crop

:: ============================================================
:: CONFIGURATION
:: ============================================================

set "INPUT=%~dp0Input"
set "OUTPUT=%~dp0Output"

:: ============================================================
:: CHECK IMAGEMAGICK
:: ============================================================

where magick >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: ImageMagick was not found.
    echo.
    echo Please install ImageMagick and make sure "magick" is
    echo available in PATH.
    echo.
    pause
    exit /b 1
)

:: ============================================================
:: CREATE FOLDERS
:: ============================================================

if not exist "%INPUT%" mkdir "%INPUT%"
if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ============================================================
:: MENU
:: ============================================================

:MENU

cls

echo ============================================================
echo                       IMAGE CROP
echo ============================================================
echo.
echo Input : %INPUT%
echo Output: %OUTPUT%
echo.
echo Select crop ratio:
echo.
echo [1] 1:1   - Square
echo [2] 4:5   - Portrait
echo [3] 16:9  - Landscape
echo [4] 9:16  - Vertical
echo [Q] Quit
echo.

set "CHOICE="
set /p "CHOICE=Enter choice: "

if /i "%CHOICE%"=="1" (
    set "RATIO=1:1"
    set "WIDTH=1"
    set "HEIGHT=1"
    goto CONFIRM
)

if /i "%CHOICE%"=="2" (
    set "RATIO=4:5"
    set "WIDTH=4"
    set "HEIGHT=5"
    goto CONFIRM
)

if /i "%CHOICE%"=="3" (
    set "RATIO=16:9"
    set "WIDTH=16"
    set "HEIGHT=9"
    goto CONFIRM
)

if /i "%CHOICE%"=="4" (
    set "RATIO=9:16"
    set "WIDTH=9"
    set "HEIGHT=16"
    goto CONFIRM
)

if /i "%CHOICE%"=="Q" exit /b 0

echo.
echo Invalid choice.
pause
goto MENU

:: ============================================================
:: CONFIRM
:: ============================================================

:CONFIRM

cls

echo ============================================================
echo                       IMAGE CROP
echo ============================================================
echo.
echo Crop Ratio: %RATIO%
echo.
echo The image will be cropped from the center.
echo The original aspect ratio will not be stretched.
echo.
echo Input : %INPUT%
echo Output: %OUTPUT%
echo.

set "CONFIRM="
set /p "CONFIRM=Start cropping? [Y/N]: "

if /i not "%CONFIRM%"=="Y" goto MENU

:: ============================================================
:: PROCESS FILES
:: ============================================================

set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0
set /a TOTAL=0

echo.
echo ============================================================
echo                    STARTING IMAGE CROP
echo ============================================================
echo.

for %%F in ("%INPUT%\*.jpg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.png") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.webp") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.bmp") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.gif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.avif") do call :PROCESS_IMAGE "%%~fF"

echo.
echo ============================================================
echo                         SUMMARY
echo ============================================================
echo.
echo Total   : %TOTAL%
echo Success : %SUCCESS%
echo Failed  : %FAILED%
echo Skipped : %SKIPPED%
echo.
echo Output folder:
echo %OUTPUT%
echo.
pause
exit /b 0


:: ============================================================
:: PROCESS IMAGE
:: ============================================================

:PROCESS_IMAGE

set /a TOTAL+=1

set "INPUT_FILE=%~1"
set "FILENAME=%~nx1"
set "NAME=%~n1"
set "EXT=%~x1"

set "OUTPUT_FILE=%OUTPUT%\%NAME%%EXT%"

echo Processing: %FILENAME%

if exist "%OUTPUT_FILE%" (
    echo   SKIPPED - Output already exists.
    echo.
    set /a SKIPPED+=1
    exit /b
)

:: ============================================================
:: CENTER CROP
:: ============================================================

magick "%INPUT_FILE%" ^
    -gravity center ^
    -crop "%WIDTH%:%HEIGHT%!" ^
    +repage ^
    "%OUTPUT_FILE%"

if errorlevel 1 (
    echo   FAILED
    echo.

    if exist "%OUTPUT_FILE%" del /q "%OUTPUT_FILE%" >nul 2>&1

    set /a FAILED+=1
    exit /b
)

echo   SUCCESS
echo.

set /a SUCCESS+=1

exit /b