@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Image Compression - ImageMagick

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ============================================================
:: CHECK IMAGEMAGICK
:: ============================================================

where magick >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] ImageMagick was not found.
    echo.
    echo Please install ImageMagick and make sure "magick"
    echo is available in PATH.
    echo.
    pause
    exit /b 1
)

:: ============================================================
:: CHECK INPUT
:: ============================================================

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder was not found:
    echo "%INPUT%"
    echo.
    mkdir "%INPUT%" >nul 2>&1
    echo Input folder has been created.
    echo Add your images and run the tool again.
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ============================================================
:: SETTINGS
:: ============================================================

:MENU

cls
echo ============================================================
echo                   IMAGE COMPRESSION
echo                   ImageMagick
echo ============================================================
echo.
echo Input : "%INPUT%"
echo Output: "%OUTPUT%"
echo.
echo Select compression quality:
echo.
echo [1] High Quality       - Quality 90
echo [2] Balanced           - Quality 85
echo [3] Smaller Size       - Quality 80
echo [4] More Compression   - Quality 70
echo [Q] Quit
echo.

choice /C 1234Q /N /M "Select an option: "

if errorlevel 5 exit /b 0
if errorlevel 4 set "QUALITY=70" & set "MODE=More Compression" & goto CONFIRM
if errorlevel 3 set "QUALITY=80" & set "MODE=Smaller Size" & goto CONFIRM
if errorlevel 2 set "QUALITY=85" & set "MODE=Balanced" & goto CONFIRM
if errorlevel 1 set "QUALITY=90" & set "MODE=High Quality" & goto CONFIRM

:: ============================================================
:: CONFIRM
:: ============================================================

:CONFIRM

cls
echo ============================================================
echo                   IMAGE COMPRESSION
echo ============================================================
echo.
echo Compression mode: %MODE%
echo Quality          : %QUALITY%
echo.
echo Input formats:
echo JPG / JPEG / PNG / WEBP / TIFF / AVIF
echo.
echo Output folder:
echo "%OUTPUT%"
echo.
choice /C YN /N /M "Start compression? [Y/N]: "

if errorlevel 2 goto MENU

:: ============================================================
:: START COMPRESSION
:: ============================================================

:START_COMPRESSION

set /A FOUND=0
set /A CURRENT=0
set /A SUCCESS=0
set /A FAILED=0
set /A SKIPPED=0

echo.
echo ============================================================
echo                   STARTING COMPRESSION
echo ============================================================
echo.

:: ------------------------------------------------------------
:: JPG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.jpg") do call :PROCESS_JPG "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :PROCESS_JPG "%%~fF"

:: ------------------------------------------------------------
:: PNG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.png") do call :PROCESS_PNG "%%~fF"

:: ------------------------------------------------------------
:: WEBP
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.webp") do call :PROCESS_WEBP "%%~fF"

:: ------------------------------------------------------------
:: TIFF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.tif") do call :PROCESS_TIFF "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :PROCESS_TIFF "%%~fF"

:: ------------------------------------------------------------
:: AVIF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.avif") do call :PROCESS_AVIF "%%~fF"

:: ============================================================
:: SUMMARY
:: ============================================================

echo.
echo ============================================================
echo                 COMPRESSION COMPLETE
echo ============================================================
echo.
echo Total files : %FOUND%
echo Successful  : %SUCCESS%
echo Failed      : %FAILED%
echo Skipped     : %SKIPPED%
echo.
echo Mode        : %MODE%
echo Quality     : %QUALITY%
echo Output      : "%OUTPUT%"
echo.
echo ============================================================
echo.

pause
exit /b 0


:: ============================================================
:: PROCESS JPG
:: ============================================================

:PROCESS_JPG

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%%~x1"

echo [%CURRENT%] Processing: %NAME%%~x1

if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

magick "%INPUT_FILE%" -strip -quality %QUALITY% "%OUTPUT_FILE%"

goto CHECK_RESULT


:: ============================================================
:: PROCESS PNG
:: ============================================================

:PROCESS_PNG

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%.png"

echo [%CURRENT%] Processing: %NAME%.png

if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

magick "%INPUT_FILE%" -strip -define png:compression-level=9 "%OUTPUT_FILE%"

goto CHECK_RESULT


:: ============================================================
:: PROCESS WEBP
:: ============================================================

:PROCESS_WEBP

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%.webp"

echo [%CURRENT%] Processing: %NAME%.webp

if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

magick "%INPUT_FILE%" -strip -quality %QUALITY% "%OUTPUT_FILE%"

goto CHECK_RESULT


:: ============================================================
:: PROCESS TIFF
:: ============================================================

:PROCESS_TIFF

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%%~x1"

echo [%CURRENT%] Processing: %NAME%%~x1

if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

magick "%INPUT_FILE%" -strip -compress Zip "%OUTPUT_FILE%"

goto CHECK_RESULT


:: ============================================================
:: PROCESS AVIF
:: ============================================================

:PROCESS_AVIF

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%.avif"

echo [%CURRENT%] Processing: %NAME%.avif

if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

magick "%INPUT_FILE%" -strip -quality %QUALITY% "%OUTPUT_FILE%"

goto CHECK_RESULT


:: ============================================================
:: CHECK RESULT
:: ============================================================

:CHECK_RESULT

if errorlevel 1 (
    echo     [FAILED] Compression failed.

    if exist "%OUTPUT_FILE%" del /Q "%OUTPUT_FILE%" >nul 2>&1

    set /A FAILED+=1
    echo.
    exit /b 0
)

if not exist "%OUTPUT_FILE%" (
    echo     [FAILED] Output file was not created.
    set /A FAILED+=1
    echo.
    exit /b 0
)

echo     [SUCCESS] %NAME%%~x1
set /A SUCCESS+=1
echo.

exit /b 0