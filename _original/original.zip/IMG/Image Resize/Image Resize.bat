@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Image Resize - ImageMagick

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

:: ============================================================
:: CHECK IMAGEMAGICK
:: ============================================================

where magick >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] ImageMagick was not found.
    echo.
    echo Please install ImageMagick and make sure "magick"
    echo is available in PATH.
    echo.
    pause
    exit /b 1
)

:: ============================================================
:: CHECK INPUT
:: ============================================================

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder was not found:
    echo "%INPUT%"
    echo.
    mkdir "%INPUT%" >nul 2>&1
    echo Input folder has been created.
    echo Add your images and run the tool again.
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ============================================================
:: MENU
:: ============================================================

:MENU

cls
echo ============================================================
echo                      IMAGE RESIZE
echo                      ImageMagick
echo ============================================================
echo.
echo Input : "%INPUT%"
echo Output: "%OUTPUT%"
echo.
echo Select maximum dimensions:
echo.
echo [1] 1920 x 1080
echo [2] 1600 x 1600
echo [3] 1280 x 1280
echo [4] Custom dimensions
echo [Q] Quit
echo.

choice /C 1234Q /N /M "Select an option: "

if errorlevel 5 exit /b 0
if errorlevel 4 goto CUSTOM
if errorlevel 3 set "WIDTH=1280" & set "HEIGHT=1280" & goto CONFIRM
if errorlevel 2 set "WIDTH=1600" & set "HEIGHT=1600" & goto CONFIRM
if errorlevel 1 set "WIDTH=1920" & set "HEIGHT=1080" & goto CONFIRM

:: ============================================================
:: CUSTOM DIMENSIONS
:: ============================================================

:CUSTOM

echo.
set /P "WIDTH=Enter maximum width: "
set /P "HEIGHT=Enter maximum height: "

if not defined WIDTH goto MENU
if not defined HEIGHT goto MENU

:: ============================================================
:: CONFIRM
:: ============================================================

:CONFIRM

cls
echo ============================================================
echo                      IMAGE RESIZE
echo ============================================================
echo.
echo Maximum Width : %WIDTH% px
echo Maximum Height: %HEIGHT% px
echo.
echo Aspect Ratio  : Preserved
echo Upscaling     : Disabled
echo.
echo Output folder:
echo "%OUTPUT%"
echo.
choice /C YN /N /M "Start resizing? [Y/N]: "

if errorlevel 2 goto MENU

:: ============================================================
:: START RESIZE
:: ============================================================

:START_RESIZE

set /A FOUND=0
set /A CURRENT=0
set /A SUCCESS=0
set /A FAILED=0
set /A SKIPPED=0

echo.
echo ============================================================
echo                      STARTING RESIZE
echo ============================================================
echo.

:: ------------------------------------------------------------
:: JPG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.jpg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: PNG
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.png") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: WEBP
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.webp") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: TIFF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.tif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: BMP
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.bmp") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: GIF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.gif") do call :PROCESS_IMAGE "%%~fF"

:: ------------------------------------------------------------
:: AVIF
:: ------------------------------------------------------------

for %%F in ("%INPUT%\*.avif") do call :PROCESS_IMAGE "%%~fF"

:: ============================================================
:: SUMMARY
:: ============================================================

echo.
echo ============================================================
echo                       RESIZE COMPLETE
echo ============================================================
echo.
echo Total files : %FOUND%
echo Successful  : %SUCCESS%
echo Failed      : %FAILED%
echo Skipped     : %SKIPPED%
echo.
echo Maximum size: %WIDTH% x %HEIGHT% px
echo Aspect Ratio : Preserved
echo Output      : "%OUTPUT%"
echo.
echo ============================================================
echo.

pause
exit /b 0


:: ============================================================
:: PROCESS IMAGE
:: ============================================================

:PROCESS_IMAGE

set /A CURRENT+=1
set /A FOUND+=1

set "INPUT_FILE=%~1"
set "NAME=%~n1"
set "EXT=%~x1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%%EXT%"

echo [%CURRENT%] Processing: %NAME%%EXT%

:: Skip if output already exists
if exist "%OUTPUT_FILE%" (
    echo     [SKIPPED] Output already exists.
    set /A SKIPPED+=1
    echo.
    exit /b 0
)

:: ============================================================
:: RESIZE
:: ============================================================

magick "%INPUT_FILE%" -resize "%WIDTH%x%HEIGHT%>" "%OUTPUT_FILE%"

:: ============================================================
:: CHECK RESULT
:: ============================================================

if errorlevel 1 (
    echo     [FAILED] Resize failed.

    if exist "%OUTPUT_FILE%" del /Q "%OUTPUT_FILE%" >nul 2>&1

    set /A FAILED+=1
    echo.
    exit /b 0
)

if not exist "%OUTPUT_FILE%" (
    echo     [FAILED] Output file was not created.
    set /A FAILED+=1
    echo.
    exit /b 0
)

echo     [SUCCESS] %NAME%%EXT%
set /A SUCCESS+=1
echo.

exit /b 0