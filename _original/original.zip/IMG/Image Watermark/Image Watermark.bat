@echo off
setlocal EnableExtensions

title Image Watermark

set "INPUT=%~dp0Input"
set "OUTPUT=%~dp0Output"
set "WATERMARK_FOLDER=%~dp0Watermark"

where magick >nul 2>&1
if errorlevel 1 (
    echo.
    echo ============================================================
    echo ERROR: ImageMagick was not found.
    echo ============================================================
    echo.
    echo Please install ImageMagick and make sure "magick"
    echo is available in PATH.
    echo.
    pause
    exit /b 1
)

if not exist "%INPUT%" mkdir "%INPUT%"
if not exist "%OUTPUT%" mkdir "%OUTPUT%"
if not exist "%WATERMARK_FOLDER%" mkdir "%WATERMARK_FOLDER%"

:MENU
cls
echo ============================================================
echo                    IMAGE WATERMARK
echo ============================================================
echo.
echo Input : %INPUT%
echo Output: %OUTPUT%
echo.
echo Select watermark type:
echo.
echo [1] Text Watermark
echo [2] Logo Watermark
echo [Q] Quit
echo.

set "TYPE="
set /p "TYPE=Enter choice: "

if "%TYPE%"=="1" goto TEXT_SETUP
if "%TYPE%"=="2" goto LOGO_SETUP
if /i "%TYPE%"=="Q" exit /b 0

echo.
echo Invalid choice.
pause
goto MENU


:TEXT_SETUP
cls
echo ============================================================
echo                    TEXT WATERMARK
echo ============================================================
echo.

set "WATERMARK_TEXT="
set /p "WATERMARK_TEXT=Enter watermark text: "

if not defined WATERMARK_TEXT (
    echo.
    echo Text cannot be empty.
    pause
    goto MENU
)

goto COMMON_SETUP


:LOGO_SETUP
cls
echo ============================================================
echo                    LOGO WATERMARK
echo ============================================================
echo.

set "LOGO="
set /a LOGO_COUNT=0

for %%F in (
    "%WATERMARK_FOLDER%\*.png"
    "%WATERMARK_FOLDER%\*.jpg"
    "%WATERMARK_FOLDER%\*.jpeg"
    "%WATERMARK_FOLDER%\*.webp"
    "%WATERMARK_FOLDER%\*.tif"
    "%WATERMARK_FOLDER%\*.tiff"
    "%WATERMARK_FOLDER%\*.bmp"
    "%WATERMARK_FOLDER%\*.gif"
    "%WATERMARK_FOLDER%\*.avif"
) do (
    if exist "%%~fF" (
        set /a LOGO_COUNT+=1
        set "LOGO=%%~fF"
    )
)

if %LOGO_COUNT% EQU 0 (
    echo No watermark image was found.
    echo.
    echo Place ONE image inside:
    echo.
    echo %WATERMARK_FOLDER%
    echo.
    echo The filename does not matter.
    echo.
    pause
    goto MENU
)

if %LOGO_COUNT% GTR 1 (
    echo Multiple watermark images were found.
    echo.
    echo Please keep only ONE image inside:
    echo.
    echo %WATERMARK_FOLDER%
    echo.
    pause
    goto MENU
)

echo Watermark image:
echo %LOGO%
echo.

goto COMMON_SETUP


:COMMON_SETUP
cls
echo ============================================================
echo                 WATERMARK COUNT
echo ============================================================
echo.
echo [1] One Watermark
echo [2] Two Watermarks
echo [3] Three Watermarks
echo [4] Four Watermarks
echo [5] Five Watermarks
echo [6] Six Watermarks
echo [7] Seven Watermarks
echo [8] Eight Watermarks
echo [9] Nine Watermarks
echo.

set "COUNT="
set /p "COUNT=Enter choice: "

if "%COUNT%"=="1" goto POSITION_1
if "%COUNT%"=="2" goto POSITION_2
if "%COUNT%"=="3" goto POSITION_3
if "%COUNT%"=="4" goto POSITION_4
if "%COUNT%"=="5" goto POSITION_5
if "%COUNT%"=="6" goto POSITION_6
if "%COUNT%"=="7" goto POSITION_7
if "%COUNT%"=="8" goto POSITION_8
if "%COUNT%"=="9" goto POSITION_9

echo.
echo Invalid choice.
pause

if "%TYPE%"=="1" goto TEXT_SETUP
goto LOGO_SETUP


:POSITION_1
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_2
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_3
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 3
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_4
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 3
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 4
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_5
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 3
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 4
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 5
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_6
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 3
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 4
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 5
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 6
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_7
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 3
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 4
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 5
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 6
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 7
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_8
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 3
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 4
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 5
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 6
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 7
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 8
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:POSITION_9
call :GET_POSITION 1
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 2
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 3
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 4
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 5
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 6
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 7
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 8
if errorlevel 1 goto COMMON_SETUP
call :GET_POSITION 9
if errorlevel 1 goto COMMON_SETUP
goto ROTATION_SETUP


:GET_POSITION
set "POSITION="
set "SELECTED_GRAVITY="

echo.
echo ------------------------------------------------------------
echo Watermark %1 Position
echo ------------------------------------------------------------
echo.
echo [1] Top Left
echo [2] Top Center
echo [3] Top Right
echo [4] Center Left
echo [5] Center
echo [6] Center Right
echo [7] Bottom Left
echo [8] Bottom Center
echo [9] Bottom Right
echo.

set /p "POSITION=Enter choice: "

if "%POSITION%"=="1" set "SELECTED_GRAVITY=northwest"
if "%POSITION%"=="2" set "SELECTED_GRAVITY=north"
if "%POSITION%"=="3" set "SELECTED_GRAVITY=northeast"
if "%POSITION%"=="4" set "SELECTED_GRAVITY=west"
if "%POSITION%"=="5" set "SELECTED_GRAVITY=center"
if "%POSITION%"=="6" set "SELECTED_GRAVITY=east"
if "%POSITION%"=="7" set "SELECTED_GRAVITY=southwest"
if "%POSITION%"=="8" set "SELECTED_GRAVITY=south"
if "%POSITION%"=="9" set "SELECTED_GRAVITY=southeast"

if not defined SELECTED_GRAVITY (
    echo.
    echo Invalid position.
    pause
    exit /b 1
)

if "%1"=="1" set "GRAVITY1=%SELECTED_GRAVITY%"
if "%1"=="2" set "GRAVITY2=%SELECTED_GRAVITY%"
if "%1"=="3" set "GRAVITY3=%SELECTED_GRAVITY%"
if "%1"=="4" set "GRAVITY4=%SELECTED_GRAVITY%"
if "%1"=="5" set "GRAVITY5=%SELECTED_GRAVITY%"
if "%1"=="6" set "GRAVITY6=%SELECTED_GRAVITY%"
if "%1"=="7" set "GRAVITY7=%SELECTED_GRAVITY%"
if "%1"=="8" set "GRAVITY8=%SELECTED_GRAVITY%"
if "%1"=="9" set "GRAVITY9=%SELECTED_GRAVITY%"

exit /b 0


:ROTATION_SETUP
cls
echo ============================================================
echo                    WATERMARK ROTATION
echo ============================================================
echo.
echo [1] Normal
echo [2] Tilt Left  (-8 degrees)
echo [3] Tilt Right (+8 degrees)
echo.

set "ROTATION_CHOICE="
set /p "ROTATION_CHOICE=Enter choice: "

set "ROTATION=0"

if "%ROTATION_CHOICE%"=="1" set "ROTATION=0"
if "%ROTATION_CHOICE%"=="2" set "ROTATION=-8"
if "%ROTATION_CHOICE%"=="3" set "ROTATION=8"

if not "%ROTATION_CHOICE%"=="1" if not "%ROTATION_CHOICE%"=="2" if not "%ROTATION_CHOICE%"=="3" (
    echo.
    echo Invalid choice.
    pause
    goto COMMON_SETUP
)

goto SIZE_SETUP


:SIZE_SETUP
cls
echo ============================================================
echo                    WATERMARK SIZE
echo ============================================================
echo.

if "%TYPE%"=="1" goto TEXT_SIZE_SETUP
goto LOGO_SIZE_SETUP


:TEXT_SIZE_SETUP
echo Text size:
echo.
echo [1] Small  - 36
echo [2] Medium - 64
echo [3] Large  - 96
echo [4] Custom
echo.

set "SIZE_CHOICE="
set /p "SIZE_CHOICE=Enter choice: "

set "SIZE="

if "%SIZE_CHOICE%"=="1" set "SIZE=36"
if "%SIZE_CHOICE%"=="2" set "SIZE=64"
if "%SIZE_CHOICE%"=="3" set "SIZE=96"

if "%SIZE_CHOICE%"=="4" (
    set /p "SIZE=Enter font size: "
)

if not defined SIZE (
    echo.
    echo Invalid size.
    pause
    goto SIZE_SETUP
)

goto OPACITY_SETUP


:LOGO_SIZE_SETUP
echo Logo size relative to image width:
echo.
echo [1] Small  - 15%%
echo [2] Medium - 25%%
echo [3] Large  - 35%%
echo [4] Custom
echo.

set "SIZE_CHOICE="
set /p "SIZE_CHOICE=Enter choice: "

set "SIZE="

if "%SIZE_CHOICE%"=="1" set "SIZE=15"
if "%SIZE_CHOICE%"=="2" set "SIZE=25"
if "%SIZE_CHOICE%"=="3" set "SIZE=35"

if "%SIZE_CHOICE%"=="4" (
    set /p "SIZE=Enter logo size percentage: "
)

if not defined SIZE (
    echo.
    echo Invalid size.
    pause
    goto SIZE_SETUP
)

goto OPACITY_SETUP


:OPACITY_SETUP
echo.
set "OPACITY="
set /p "OPACITY=Enter opacity (10-100, default 60): "

if not defined OPACITY set "OPACITY=60"

goto CONFIRM


:CONFIRM
cls
echo ============================================================
echo                   WATERMARK SETTINGS
echo ============================================================
echo.

if "%TYPE%"=="1" (
    echo Type    : Text
    echo Text    : %WATERMARK_TEXT%
) else (
    echo Type    : Logo
    echo Logo    : %LOGO%
)

echo.
echo Count   : %COUNT%
echo Rotation: %ROTATION% degrees
echo Size    : %SIZE%
echo Opacity : %OPACITY%%%
echo.
echo Positions:
echo.
echo Watermark 1: %GRAVITY1%
if %COUNT% GEQ 2 echo Watermark 2: %GRAVITY2%
if %COUNT% GEQ 3 echo Watermark 3: %GRAVITY3%
if %COUNT% GEQ 4 echo Watermark 4: %GRAVITY4%
if %COUNT% GEQ 5 echo Watermark 5: %GRAVITY5%
if %COUNT% GEQ 6 echo Watermark 6: %GRAVITY6%
if %COUNT% GEQ 7 echo Watermark 7: %GRAVITY7%
if %COUNT% GEQ 8 echo Watermark 8: %GRAVITY8%
if %COUNT% GEQ 9 echo Watermark 9: %GRAVITY9%

echo.
echo Input : %INPUT%
echo Output: %OUTPUT%
echo.

set "CONFIRM="
set /p "CONFIRM=Start watermarking? [Y/N]: "

if /i not "%CONFIRM%"=="Y" goto MENU

goto PROCESS


:PROCESS
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0
set /a TOTAL=0

echo.
echo ============================================================
echo                  STARTING WATERMARKING
echo ============================================================
echo.

for %%F in ("%INPUT%\*.jpg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.png") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.webp") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.bmp") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.gif") do call :PROCESS_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.avif") do call :PROCESS_IMAGE "%%~fF"

echo.
echo ============================================================
echo                         SUMMARY
echo ============================================================
echo.
echo Total   : %TOTAL%
echo Success : %SUCCESS%
echo Failed  : %FAILED%
echo Skipped : %SKIPPED%
echo.
echo Output folder:
echo %OUTPUT%
echo.

pause
exit /b 0


:PROCESS_IMAGE
set /a TOTAL+=1

set "INPUT_FILE=%~1"
set "FILENAME=%~nx1"
set "NAME=%~n1"
set "EXT=%~x1"
set "OUTPUT_FILE=%OUTPUT%\%NAME%%EXT%"

echo Processing: %FILENAME%

if exist "%OUTPUT_FILE%" (
    echo   SKIPPED - Output already exists.
    echo.
    set /a SKIPPED+=1
    exit /b
)

set "WORK_FILE=%TEMP%\watermark_work_%RANDOM%_%RANDOM%.png"

magick "%INPUT_FILE%" -auto-orient "%WORK_FILE%"

if errorlevel 1 goto FAILED_IMAGE

if "%TYPE%"=="1" goto CREATE_TEXT_WATERMARK
goto CREATE_LOGO_WATERMARK


:CREATE_TEXT_WATERMARK
set "WATERMARK_FILE=%TEMP%\watermark_text_%RANDOM%_%RANDOM%.png"

magick ^
    -background none ^
    -fill white ^
    -pointsize %SIZE% ^
    -gravity center ^
    label:"%WATERMARK_TEXT%" ^
    -trim ^
    +repage ^
    "%WATERMARK_FILE%"

if errorlevel 1 goto FAILED_IMAGE

magick "%WATERMARK_FILE%" ^
    -alpha set ^
    -channel A ^
    -evaluate multiply 0.%OPACITY% ^
    +channel ^
    "%WATERMARK_FILE%"

if errorlevel 1 goto FAILED_IMAGE

if "%ROTATION%"=="0" goto TEXT_READY

set "ROTATED_WATERMARK=%TEMP%\watermark_text_rotated_%RANDOM%_%RANDOM%.png"

magick "%WATERMARK_FILE%" ^
    -background none ^
    -rotate %ROTATION% ^
    +repage ^
    "%ROTATED_WATERMARK%"

if errorlevel 1 goto FAILED_IMAGE

del /q "%WATERMARK_FILE%" >nul 2>&1

set "WATERMARK_FILE=%ROTATED_WATERMARK%"

:TEXT_READY
goto APPLY_WATERMARKS


:CREATE_LOGO_WATERMARK
for /f "delims=" %%W in ('magick identify -format "%%w" "%INPUT_FILE%"') do set "IMAGE_WIDTH=%%W"

if not defined IMAGE_WIDTH goto FAILED_IMAGE

set /a LOGO_WIDTH=IMAGE_WIDTH*SIZE/100

if %LOGO_WIDTH% LSS 1 goto FAILED_IMAGE

set "WATERMARK_FILE=%TEMP%\watermark_logo_%RANDOM%_%RANDOM%.png"

magick "%LOGO%" ^
    -resize "%LOGO_WIDTH%x" ^
    -alpha set ^
    -channel A ^
    -evaluate multiply 0.%OPACITY% ^
    +channel ^
    "%WATERMARK_FILE%"

if errorlevel 1 goto FAILED_IMAGE

if "%ROTATION%"=="0" goto LOGO_READY

set "ROTATED_WATERMARK=%TEMP%\watermark_logo_rotated_%RANDOM%_%RANDOM%.png"

magick "%WATERMARK_FILE%" ^
    -background none ^
    -rotate %ROTATION% ^
    +repage ^
    "%ROTATED_WATERMARK%"

if errorlevel 1 goto FAILED_IMAGE

del /q "%WATERMARK_FILE%" >nul 2>&1

set "WATERMARK_FILE=%ROTATED_WATERMARK%"


:LOGO_READY
goto APPLY_WATERMARKS


:APPLY_WATERMARKS

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY1% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


if %COUNT% LSS 2 goto WATERMARK_3

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY2% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:WATERMARK_3
if %COUNT% LSS 3 goto WATERMARK_4

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY3% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:WATERMARK_4
if %COUNT% LSS 4 goto WATERMARK_5

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY4% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:WATERMARK_5
if %COUNT% LSS 5 goto WATERMARK_6

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY5% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:WATERMARK_6
if %COUNT% LSS 6 goto WATERMARK_7

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY6% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:WATERMARK_7
if %COUNT% LSS 7 goto WATERMARK_8

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY7% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:WATERMARK_8
if %COUNT% LSS 8 goto WATERMARK_9

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY8% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:WATERMARK_9
if %COUNT% LSS 9 goto SAVE_OUTPUT

set "NEXT_WORK=%TEMP%\watermark_next_%RANDOM%_%RANDOM%.png"

magick "%WORK_FILE%" ^
    "%WATERMARK_FILE%" ^
    -gravity %GRAVITY9% ^
    -geometry +30+30 ^
    -composite ^
    "%NEXT_WORK%"

if errorlevel 1 goto FAILED_IMAGE

move /y "%NEXT_WORK%" "%WORK_FILE%" >nul

if errorlevel 1 goto FAILED_IMAGE


:SAVE_OUTPUT
magick "%WORK_FILE%" "%OUTPUT_FILE%"

if errorlevel 1 goto FAILED_IMAGE

if exist "%WORK_FILE%" del /q "%WORK_FILE%" >nul 2>&1
if exist "%WATERMARK_FILE%" del /q "%WATERMARK_FILE%" >nul 2>&1
if exist "%ROTATED_WATERMARK%" del /q "%ROTATED_WATERMARK%" >nul 2>&1
if exist "%NEXT_WORK%" del /q "%NEXT_WORK%" >nul 2>&1

echo   SUCCESS
echo.

set /a SUCCESS+=1

exit /b


:FAILED_IMAGE
if exist "%WORK_FILE%" del /q "%WORK_FILE%" >nul 2>&1
if exist "%WATERMARK_FILE%" del /q "%WATERMARK_FILE%" >nul 2>&1
if exist "%ROTATED_WATERMARK%" del /q "%ROTATED_WATERMARK%" >nul 2>&1
if exist "%NEXT_WORK%" del /q "%NEXT_WORK%" >nul 2>&1
if exist "%OUTPUT_FILE%" del /q "%OUTPUT_FILE%" >nul 2>&1

echo   FAILED
echo.

set /a FAILED+=1

exit /b