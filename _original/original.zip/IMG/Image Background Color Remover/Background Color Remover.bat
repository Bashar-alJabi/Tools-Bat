@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Background Color Remover - ImageMagick

echo.
echo ==================================================
echo             BACKGROUND COLOR REMOVER
echo ==================================================
echo.

REM ==================================================
REM Paths
REM ==================================================

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"

REM ==================================================
REM Check ImageMagick
REM ==================================================

where magick >nul 2>&1

if errorlevel 1 (
    echo ERROR: ImageMagick was not found.
    echo.
    echo Make sure ImageMagick is installed and added to PATH.
    echo.
    pause
    exit /b 1
)

REM ==================================================
REM Check Input
REM ==================================================

if not exist "%INPUT%" (
    echo ERROR: Input folder was not found.
    echo.
    echo Expected:
    echo %INPUT%
    echo.
    pause
    exit /b 1
)

REM ==================================================
REM Create Output
REM ==================================================

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

REM ==================================================
REM Select Background Color
REM ==================================================

:COLOR_MENU

echo.
echo Select background color:
echo.
echo 1. White
echo 2. Black
echo 3. Custom Color
echo.

set "COLOR_CHOICE="
set /p "COLOR_CHOICE=Choose an option [1-3]: "

if "%COLOR_CHOICE%"=="1" (
    set "COLOR=white"
    goto FUZZ_MENU
)

if "%COLOR_CHOICE%"=="2" (
    set "COLOR=black"
    goto FUZZ_MENU
)

if "%COLOR_CHOICE%"=="3" (
    echo.
    set "COLOR="
    set /p "COLOR=Enter color (example: #00FF00): "

    if not defined COLOR (
        echo.
        echo ERROR: No color was entered.
        goto COLOR_MENU
    )

    goto FUZZ_MENU
)

echo.
echo Invalid choice.
goto COLOR_MENU

REM ==================================================
REM Select Fuzz
REM ==================================================

:FUZZ_MENU

echo.
echo Background color:
echo    %COLOR%
echo.
echo Select color tolerance:
echo.
echo 1. 5%%
echo 2. 10%%
echo 3. 20%%
echo 4. Custom
echo.

set "FUZZ_CHOICE="
set /p "FUZZ_CHOICE=Choose an option [1-4]: "

if "%FUZZ_CHOICE%"=="1" (
    set "FUZZ=5%%"
    goto PROCESS
)

if "%FUZZ_CHOICE%"=="2" (
    set "FUZZ=10%%"
    goto PROCESS
)

if "%FUZZ_CHOICE%"=="3" (
    set "FUZZ=20%%"
    goto PROCESS
)

if "%FUZZ_CHOICE%"=="4" (
    echo.
    set "FUZZ="
    set /p "FUZZ=Enter fuzz percentage (example: 12%%): "

    if not defined FUZZ (
        echo.
        echo ERROR: No fuzz value was entered.
        goto FUZZ_MENU
    )

    goto PROCESS
)

echo.
echo Invalid choice.
goto FUZZ_MENU

REM ==================================================
REM Count Images
REM ==================================================

:PROCESS

set /a COUNT=0

for %%F in (
    "%INPUT%\*.jpg"
    "%INPUT%\*.jpeg"
    "%INPUT%\*.png"
    "%INPUT%\*.webp"
    "%INPUT%\*.bmp"
    "%INPUT%\*.tif"
    "%INPUT%\*.tiff"
    "%INPUT%\*.gif"
    "%INPUT%\*.avif"
) do (
    if exist "%%~F" set /a COUNT+=1
)

if %COUNT% EQU 0 (
    echo.
    echo No supported images found in:
    echo %INPUT%
    echo.
    pause
    exit /b 0
)

REM ==================================================
REM Information
REM ==================================================

echo.
echo ==================================================
echo                  SETTINGS
echo ==================================================
echo.

echo Background color:
echo    %COLOR%
echo.
echo Fuzz:
echo    %FUZZ%
echo.
echo Found %COUNT% image(s).
echo.

echo ==================================================
echo                  PROCESSING
echo ==================================================
echo.

REM ==================================================
REM Counters
REM ==================================================

set /a CURRENT=0
set /a SUCCESS=0
set /a FAILED=0
set /a SKIPPED=0

REM ==================================================
REM Process Images
REM ==================================================

for %%F in (
    "%INPUT%\*.jpg"
    "%INPUT%\*.jpeg"
    "%INPUT%\*.png"
    "%INPUT%\*.webp"
    "%INPUT%\*.bmp"
    "%INPUT%\*.tif"
    "%INPUT%\*.tiff"
    "%INPUT%\*.gif"
    "%INPUT%\*.avif"
) do (

    if exist "%%~F" (

        set /a CURRENT+=1
        set "NAME=%%~nF"
        set "OUTPUT_FILE=%OUTPUT%\!NAME!.png"

        echo [!CURRENT!/%COUNT%] %%~nxF

        REM --------------------------------------------------
        REM Skip existing output
        REM --------------------------------------------------

        if exist "!OUTPUT_FILE!" (

            echo    SKIPPED - Output already exists
            echo.

            set /a SKIPPED+=1

        ) else (

            REM --------------------------------------------------
            REM Remove background color
            REM --------------------------------------------------

            magick "%%~F" ^
                -alpha on ^
                -fuzz %FUZZ% ^
                -transparent "%COLOR%" ^
                "!OUTPUT_FILE!"

            if errorlevel 1 (

                echo    FAILED
                echo.

                if exist "!OUTPUT_FILE!" del /q "!OUTPUT_FILE!" >nul 2>&1

                set /a FAILED+=1

            ) else (

                echo    OK - Output\!NAME!.png
                echo.

                set /a SUCCESS+=1

            )
        )
    )
)

REM ==================================================
REM Complete
REM ==================================================

echo.
echo ==================================================
echo                   COMPLETE
echo ==================================================
echo.

echo Total images:  %COUNT%
echo Successful:    %SUCCESS%
echo Failed:        %FAILED%
echo Skipped:       %SKIPPED%
echo.

echo Background color:
echo %COLOR%
echo.
echo Fuzz:
echo %FUZZ%
echo.
echo Output:
echo %OUTPUT%
echo.

pause
exit /b