@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Image Contact Sheet - ImageMagick

set "BASE=%~dp0"
set "INPUT=%BASE%Input"
set "OUTPUT=%BASE%Output"
set "LIST=%TEMP%\image_contact_sheet_%RANDOM%.txt"

:: ============================================================
:: CHECK IMAGEMAGICK
:: ============================================================

where magick >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] ImageMagick was not found.
    echo.
    echo Please install ImageMagick and make sure "magick"
    echo is available in PATH.
    echo.
    pause
    exit /b 1
)

:: ============================================================
:: CHECK INPUT
:: ============================================================

if not exist "%INPUT%" (
    echo.
    echo [ERROR] Input folder was not found:
    echo "%INPUT%"
    echo.
    mkdir "%INPUT%" >nul 2>&1
    echo Input folder has been created.
    echo Add your images and run the tool again.
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT%" mkdir "%OUTPUT%"

:: ============================================================
:: MENU
:: ============================================================

:MENU

cls
echo ============================================================
echo                    IMAGE CONTACT SHEET
echo                    ImageMagick
echo ============================================================
echo.
echo Input : "%INPUT%"
echo Output: "%OUTPUT%"
echo.
echo Select number of columns:
echo.
echo [1] 3 Columns
echo [2] 4 Columns
echo [3] 5 Columns
echo [Q] Quit
echo.

choice /C 123Q /N /M "Select an option: "

if errorlevel 4 exit /b 0
if errorlevel 3 set "COLUMNS=5" & goto CONFIRM
if errorlevel 2 set "COLUMNS=4" & goto CONFIRM
if errorlevel 1 set "COLUMNS=3" & goto CONFIRM

:: ============================================================
:: CONFIRM
:: ============================================================

:CONFIRM

cls
echo ============================================================
echo                    IMAGE CONTACT SHEET
echo ============================================================
echo.
echo Columns: %COLUMNS%
echo.
echo Images will be arranged in a Grid.
echo File names will be displayed below each image.
echo.
echo Output:
echo "%OUTPUT%\contact-sheet.png"
echo.
choice /C YN /N /M "Create contact sheet? [Y/N]: "

if errorlevel 2 goto MENU

:: ============================================================
:: PREPARE FILE LIST
:: ============================================================

if exist "%LIST%" del /Q "%LIST%" >nul 2>&1

set /A FOUND=0

echo.
echo ============================================================
echo                  SCANNING IMAGES
echo ============================================================
echo.

for %%F in ("%INPUT%\*.jpg") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.jpeg") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.png") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.webp") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tif") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.tiff") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.bmp") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.gif") do call :ADD_IMAGE "%%~fF"
for %%F in ("%INPUT%\*.avif") do call :ADD_IMAGE "%%~fF"

if %FOUND% EQU 0 (
    echo.
    echo [ERROR] No supported images were found.
    echo.
    if exist "%LIST%" del /Q "%LIST%" >nul 2>&1
    pause
    exit /b 1
)

:: ============================================================
:: CHECK EXISTING OUTPUT
:: ============================================================

set "OUTPUT_FILE=%OUTPUT%\contact-sheet.png"

if exist "%OUTPUT_FILE%" (
    echo.
    echo [SKIPPED] Contact sheet already exists:
    echo "%OUTPUT_FILE%"
    echo.
    echo Delete the existing file if you want to create a new one.
    echo.
    if exist "%LIST%" del /Q "%LIST%" >nul 2>&1
    pause
    exit /b 0
)

:: ============================================================
:: CREATE CONTACT SHEET
:: ============================================================

echo.
echo ============================================================
echo                 CREATING CONTACT SHEET
echo ============================================================
echo.
echo Total images: %FOUND%
echo Columns     : %COLUMNS%
echo.

magick montage @"%LIST%" ^
    -thumbnail 300x300 ^
    -tile %COLUMNS%x ^
    -geometry 300x300+20+45 ^
    -background white ^
    -fill black ^
    -pointsize 16 ^
    -gravity south ^
    -label "%%f" ^
    "%OUTPUT_FILE%"

if errorlevel 1 (
    echo.
    echo [FAILED] Contact sheet creation failed.

    if exist "%OUTPUT_FILE%" del /Q "%OUTPUT_FILE%" >nul 2>&1
    if exist "%LIST%" del /Q "%LIST%" >nul 2>&1

    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT_FILE%" (
    echo.
    echo [FAILED] Contact sheet was not created.

    if exist "%LIST%" del /Q "%LIST%" >nul 2>&1

    echo.
    pause
    exit /b 1
)

:: ============================================================
:: CLEANUP
:: ============================================================

if exist "%LIST%" del /Q "%LIST%" >nul 2>&1

:: ============================================================
:: SUMMARY
:: ============================================================

echo.
echo ============================================================
echo                 CONTACT SHEET COMPLETE
echo ============================================================
echo.
echo Total images : %FOUND%
echo Columns      : %COLUMNS%
echo Successful   : 1
echo Failed       : 0
echo.
echo Output:
echo "%OUTPUT_FILE%"
echo.
echo ============================================================
echo.

pause
exit /b 0


:: ============================================================
:: ADD IMAGE TO LIST
:: ============================================================

:ADD_IMAGE

set /A FOUND+=1
>>"%LIST%" echo "%~1"

exit /b 0