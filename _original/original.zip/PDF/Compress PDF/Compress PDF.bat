@echo off
setlocal EnableExtensions

title PDF Compression - Ghostscript

:: ============================================================
:: Compress PDF files using Ghostscript
:: Input files : .\Input
:: Output files: .\Output
:: ============================================================

set "SCRIPT_DIR=%~dp0"
set "INPUT_DIR=%SCRIPT_DIR%Input"
set "OUTPUT_DIR=%SCRIPT_DIR%Output"

:: Check if Ghostscript is installed
where gswin64c >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: Ghostscript was not found.
    echo.
    echo Please install Ghostscript and make sure it is available in PATH.
    echo.
    pause
    exit /b 1
)

:: Check if Input folder exists
if not exist "%INPUT_DIR%" (
    echo.
    echo ERROR: Input folder was not found.
    echo.
    echo Expected:
    echo %INPUT_DIR%
    echo.
    pause
    exit /b 1
)

:: Create Output folder if it does not exist
if not exist "%OUTPUT_DIR%" (
    mkdir "%OUTPUT_DIR%"
)

:: ============================================================
:: Select compression preset
:: ============================================================

:MENU

cls
echo.
echo ============================================================
echo                    PDF COMPRESSION
echo ============================================================
echo.
echo Select compression level:
echo.
echo [1] Screen
echo     Smallest file size - Lower quality
echo.
echo [2] Ebook
echo     Best balance between size and quality
echo.
echo [3] Printer
echo     Higher quality - Suitable for printing
echo.
echo [4] Prepress
echo     Highest quality - Professional printing
echo.
echo [5] Default
echo     General purpose
echo.
echo ============================================================
echo.

set "CHOICE="
set /p "CHOICE=Enter your choice [1-5]: "

if "%CHOICE%"=="1" (
    set "PRESET=/screen"
    set "PRESET_NAME=Screen"
    set "PRESET_DESCRIPTION=Smallest file size - Lower quality"
    goto CONFIRM
)

if "%CHOICE%"=="2" (
    set "PRESET=/ebook"
    set "PRESET_NAME=Ebook"
    set "PRESET_DESCRIPTION=Best balance between size and quality"
    goto CONFIRM
)

if "%CHOICE%"=="3" (
    set "PRESET=/printer"
    set "PRESET_NAME=Printer"
    set "PRESET_DESCRIPTION=Higher quality - Suitable for printing"
    goto CONFIRM
)

if "%CHOICE%"=="4" (
    set "PRESET=/prepress"
    set "PRESET_NAME=Prepress"
    set "PRESET_DESCRIPTION=Highest quality - Professional printing"
    goto CONFIRM
)

if "%CHOICE%"=="5" (
    set "PRESET=/default"
    set "PRESET_NAME=Default"
    set "PRESET_DESCRIPTION=General purpose"
    goto CONFIRM
)

echo.
echo Invalid choice. Please select a number from 1 to 5.
timeout /t 2 >nul
goto MENU


:: ============================================================
:: Confirm selected preset
:: ============================================================

:CONFIRM

cls
echo.
echo ============================================================
echo                    PDF COMPRESSION
echo ============================================================
echo.
echo Selected:
echo %PRESET_NAME% - %PRESET_DESCRIPTION%
echo.
echo Ghostscript preset: %PRESET%
echo.
echo Input : %INPUT_DIR%
echo Output: %OUTPUT_DIR%
echo.
echo ============================================================
echo.
choice /c YN /n /m "Continue? [Y/N]: "

if errorlevel 2 goto MENU
if errorlevel 1 goto PROCESS


:: ============================================================
:: Process PDF files
:: ============================================================

:PROCESS

echo.
echo ============================================================
echo                    PROCESSING
echo ============================================================
echo.
echo Compression: %PRESET_NAME% (%PRESET%)
echo.

set "FOUND=0"
set "SUCCESS=0"
set "FAILED=0"

for %%F in ("%INPUT_DIR%\*.pdf") do (
    set "FOUND=1"

    echo Compressing:
    echo %%~nxF
    echo.

    gswin64c ^
        -sDEVICE=pdfwrite ^
        -dCompatibilityLevel=1.4 ^
        -dPDFSETTINGS=%PRESET% ^
        -dNOPAUSE ^
        -dQUIET ^
        -dBATCH ^
        -sOutputFile="%OUTPUT_DIR%\%%~nxF" ^
        "%%F"

    if errorlevel 1 (
        echo ERROR: Failed to compress %%~nxF
        set /a FAILED+=1
    ) else (
        echo DONE: %%~nxF
        set /a SUCCESS+=1
    )

    echo.
)

if "%FOUND%"=="0" (
    echo No PDF files were found in the Input folder.
    echo.
) else (
    echo ============================================================
    echo                 PROCESSING COMPLETE
    echo ============================================================
    echo.
    echo Preset    : %PRESET_NAME%
    echo Successful: %SUCCESS%
    echo Failed    : %FAILED%
    echo.
    echo Output files are located in:
    echo %OUTPUT_DIR%
    echo.
)

pause
endlocal